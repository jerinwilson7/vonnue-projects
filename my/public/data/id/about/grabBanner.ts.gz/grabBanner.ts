import { AboutPageProps } from '@/sections/about';

export const grabBanner: AboutPageProps['grabBanner'] = {
  title: 'HUBBO POS, Mitra Pilihan Grab',
  description: `Sebagai mitra POS Pilihan Grab , HUBBO POS bertujuan untuk membantu Mitra Merchant di GrabFood menavigasi proses integrasi pengiriman dengan mudah, dan memposisikan diri mereka untuk keberhasilan yang berkelanjutan di lanskap bisnis yang terus berubah.`,
  altText:
    'Male restaurant owner in white shirt and black apron hands over food parcel to Grab driver, showcasing Hubbo POS partnership.',
};
