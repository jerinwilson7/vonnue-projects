import { AboutPageProps } from '@/sections/about';

export const missionVision: AboutPageProps['missionVision'] = {
  mission: {
    eyebrow: 'Misi Kami',
    title: 'Memberdayakan bisnis restoran apa pun skalanya',
    description: `Misi kami adalah memberdayakan bisnis restoran dengan solusi-solusi inovatif untuk mengoperasikan dan mengembangkan bisnisnya tanpa beban.`,
    altText:
      'Happy female restaurant owner and Hubbo POS customer in kitchen with cap, holding a white cup.',
  },
  vision: {
    eyebrow: 'Visi Kami',
    title:
      'Transformasi Bisnis Anda dengan Pengalaman Omni-channel yang Luar Biasa',
    description: `Visi kami adalah merevolusi industri restoran dengan menghadirkan platform Omni-channel yang memiliki teknologi canggih, tampilan antarmuka ramah pengguna, dan integrasi kanal cerdas.`,
    altText:
      'Visi kami adalah merevolusi industri restoran dengan menghadirkan platform Omni-channel yang memiliki teknologi canggih, tampilan antarmuka ramah pengguna, dan integrasi kanal cerdas.',
  },
};
