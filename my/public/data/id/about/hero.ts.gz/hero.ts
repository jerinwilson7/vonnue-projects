import { AboutPageProps } from '@/sections/about';

export const hero: AboutPageProps['hero'] = {
  chipText: 'Tentang Kami',
  title: 'Kami membantu usaha restoran tumbuh berkembang di Asia Tenggara',
  description:
    'Sistem HUBBO POS kami dibangun untuk menjadi sahabat setia Anda yang mendukung operasional bisnis di setiap langkah di sepanjang perjalanan, memungkinkan restoran untuk berfokus menghadirkan pengalaman Dine-in yang luar biasa.',
};
