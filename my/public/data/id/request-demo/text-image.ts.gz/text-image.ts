import { TextImageContainerProps } from '@/components/request-demo';

export const textImageData: TextImageContainerProps = {
  textContent: {
    header: 'Cobain kenyamanan pakai Hubbo POS, solusi kasir serba bisa!',
    bulletPointsHeader: 'Jadwalkan demo dengan HUBBO POS hari ini.',
    bulletPoints: [
      'Perbarui menu Anda dengan sekali klik',
      'Kurangi biaya tenaga kerja hingga 35%',
      'Tingkatkan penjualan rata-rata hingga 49%',
    ],
  },
  pricingImage: {
    startFromLabel: 'Mulai dari',
    amount: 'Rp.4rb',
    perDayLabel: '/hari',
    altText:
      'Close-up of a tablet with a Hubbo POS menu on it, sitting on a wooden table.',
  },
};
