import { LogoContainerProps } from '@/components/request-demo';
import { imagesLg } from '../common/marqueeImages';

export const logoContainerData: LogoContainerProps = {
  title: 'Mendukung Semua Jenis Bisnis Restoran',
  images: imagesLg,
};
