import FormSuccess from '@/assets/images/form-success.svg';
import { FormProps } from '@/components/request-demo/Form';

export const formData: FormProps = {
  successData: {
    title: 'Terima kasih atas permintaan Anda!',
    description:
      'Salah satu staf HUBBO POS kami akan menghubungi Anda dalam 3 hari kerja berikutnya',
    image: FormSuccess,
  },
  validationMessages: {
    fullName: {
      required: 'Harus diisi',
      max: 'Nama maksimal 80 karakter',
    },
    storeName: { required: 'Harus diisi' },
    phoneNumber: {
      required: 'Format tidak valid atau kolom hilang',
      typeError: 'Format tidak valid atau kolom hilang',
    },
    emailAddress: {
      required: 'Format tidak valid atau kolom hilang',
      typeError: 'Format tidak valid atau kolom hilang',
    },
    numberOfOutlets: {
      required: 'Format tidak valid atau kolom hilang',
      typeError: 'Format tidak valid atau kolom hilang',
      min: 'Ini harus lebih besar dari atau sama dengan 0',
      max: 'Ini harus kurang dari atau sama dengan 100',
    },
    city: { required: 'Harus diisi' },
    form: {
      submittedWithoutTouching: 'Semua kolom harus diisi',
      submissionError: 'Ada kesalahan! Silakan coba lagi',
    },
  },
  ctaText: 'Minta Demo Gratis',
  privacyPolicy: {
    text: 'Dengan mengirimkan, Anda setuju Hubbo untuk mengumpulkan, menggunakan, mengungkapkan dan memroses informasi yang disediakan untuk memfasilitasi dan memudahkan pemahaman terhadap layanan Hubbo (termasuk mengirimkan kepada Anda penawaran, promosi, buletin dan komunikasi pemasaran lainnya, dan menghubungi Anda untuk membagikan lebih banyak tentang layanannya), melakukan analisis pasar yang relevan dan urusan administratif yang terkait dengan Kebijakan Privasi Hubbo. Anda dapat berhenti berlangganan kapan saja melalui kanal yang disediakan di komunikasi ini.',
    linkText: ' Pemberitahuan Privasi',
  },
  formFieldLabels: {
    fullName: 'Nama',
    storeName: 'Nama toko',
    phoneNumber: 'Nomor telepon',
    emailAddress: 'Alamat email',
    numberOfOutlets: 'Jumlah outlet',
    city: 'Kota',
  },
};
