import { Common } from '@/assets/svgs';
import solutionsFeatureImg from '@/assets/images/reporting-feature.jpg';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of number calling system
export const solutionFeatures: SolutionsFeaturesProps = {
  title: 'Tingkatkan efisiensi alur kerja dan produktivitas secara keseluruhan',
  features: [
    {
      smallImage: solutionsFeatureImg,
      largeImage: solutionsFeatureImg,
      altText:
        'Man packing Avocado Tomato Salad among 7 Hubbo POS differentiated orders, showcasing order efficiency.',
      content: [
        {
          icon: Common.SmartCallingSytem,
          title: 'Pengelompokan Item Otomatis',
          body: 'Kurangi waktu persiapan dengan pengelompokan item yang efisien dan sinkronisasi pesanan otomatis.',
        },
        {
          icon: Common.AdvancedDisplaySystem,
          title: 'Bedakan pesanan berdasarkan platform',
          body: 'Sistem tampilan tiket unik kami secara otomatis membedakan  pesanan dari platform pengiriman dan dine-in, mengurangi waktu tunggu secara keseluruhan.',
        },
      ],
    },
  ],
};
