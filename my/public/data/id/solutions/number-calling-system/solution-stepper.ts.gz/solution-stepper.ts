import { SolutionsTemplateProps } from '@/sections/solutions';

const stepsToPay = [
  { step: '1', text: 'Restoran menerima pesanan' },
  { step: '2', text: "Pesanan ditampilkan 'Menyiapkan'" },
  { step: '3', text: 'Makanan siap' },
  { step: '4', text: 'Pesanan diperbarui menjadi siap diambil' },
];

export const paymentSteps: SolutionsTemplateProps['paymentSteps'] = {
  title: 'Step-by-step process',
  stepsToPay: stepsToPay,
};
