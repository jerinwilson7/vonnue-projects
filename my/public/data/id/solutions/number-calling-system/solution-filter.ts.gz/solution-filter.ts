import filterSmallImage from '@/assets/images/reporting-cta-small.png';
import filterLargeImage from '@/assets/images/reporting-cta-large.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    'Restaurant owner serving a customer in an orange t-shirt, facilitated by Hubbo POS.',
  buttonTitle: 'Minta Demo Gratis',
  buttonLink: `/request-demo`,
  title: 'Semua Operasional Restoran Anda dalam Satu Klik',
  body: 'Anda akan dapat mengecek status pengiriman Anda, pengambilan sendiri, dan pesanan makanan yang diorganisasi secara rapi oleh platfom HUBBO POS untuk meningkatkan produktivitas restoran Anda.',
};
