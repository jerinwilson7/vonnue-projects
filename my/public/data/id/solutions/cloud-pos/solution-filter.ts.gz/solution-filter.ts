import filterSmallImage from '@/assets/images/cta-small.png';
import filterLargeImage from '@/assets/images/cta-large.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    'Restaurant owner with white tablet uses HUBBO POS for reliable, efficient operational management.',
  buttonTitle: 'Minta Demo Gratis',
  buttonLink: `/request-demo`,
  title: 'Pastikan bisnis berjalan lancar dengan HUBBO POS',
  body: 'HUBBO POS, kasir berbasis penyimpanan virtual dengan mode offline, mengurangi proses manual dan menjamin pengalaman yang lancar, bahkan di hari-hari paling sibuk sekalipun.',
};
