import heroSmall from '@/assets/images/cloud-landing-small.jpg';
import heroLarge from '@/assets/images/cloud-landing-large.jpg';
import { Common } from '@/assets/svgs';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const heroBanner: SolutionsTemplateProps['heroBanner'] = {
  pageIndicatorIcon: Common.CloudPos,
  pageIndicatorTitle: 'POS Virtual',
  bannerTitle: 'Tingkatkan efisiensi dengan penyimpanan virtual (Cloud)',
  bannerBody:
    'Manfaatkan teknologi penyimpanan virtual (Cloud) agar operasi bisnis Anda lebih lancar',
  heroSmallImage: heroSmall,
  heroLargeImage: heroLarge,
  imageAlt:
    'Hubbo POS dashboard report displayed on tablet, highlighting cloud-based POS system capabilities.',
};
