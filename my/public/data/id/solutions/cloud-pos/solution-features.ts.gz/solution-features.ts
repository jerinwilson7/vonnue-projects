import { Common } from '@/assets/svgs';
import solutionsFeatureImg1 from '@/assets/images/feature-section-1.jpg';
import solutionsFeatureImg2 from '@/assets/images/feature-section-2.jpg';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of cloud POS
export const solutionFeatures: SolutionsFeaturesProps = {
  title:
    'Maksimalkan Efisiensi dan Operasional Toko dengan penyimpanan virtual (Cloud)',
  features: [
    {
      smallImage: solutionsFeatureImg1,
      largeImage: solutionsFeatureImg1,
      altText:
        'Restaurant owner serves customers using HUBBO POS for uninterrupted service, efficiency, and real-time reporting.',
      content: [
        {
          icon: Common.OfflineMode,
          title: 'Mode offline yang dapat diandalkan',
          body: 'Dapatkan pengalaman layanan yang lancar bahkan ketika internet sedang putus dengan sinkronisasi dan pencadangan data otomatis.',
        },
        {
          icon: Common.Desk,
          title: 'Tingkatkan Perputaran Meja (pada layanan makan di tempat)',
          body: 'Tingkatkan efisieni restoran dengan proses otomatis, pencegahan kesalahan, dan perputaran meja yang lebih cepat.',
        },
        {
          icon: Common.InstantReporting,
          title: 'Pelaporan instan real-time',
          body: 'Dapatkan wawasan bisnis yang terperinci kapan saja, di mana saja dengan alat intelijen bisnis HUBBO POS yang canggih.',
        },
      ],
    },

    {
      smallImage: solutionsFeatureImg2,
      largeImage: solutionsFeatureImg2,
      altText:
        'Customer in orange shirt makes mobile payment using Hubbo POS with eWallets',
      content: [
        {
          icon: Common.SupportChat,
          title: 'Dukungan Pelanggan dan Pusat Bantuan Komprehensif',
          body: 'Terhubung dengan para pakar untuk mendapatkan dukungan bisnis dan berdayakan bisnis Anda dengan aneka sumber daya berharga melalui pusat bantuan kami yang ramah pengguna.',
        },
        {
          icon: Common.Payment,
          title: 'Integrasi Pembayaran yang Lancar',
          body: 'Tingkatkan pengalaman pembayaran pelanggan Anda dengan Integrasi QRIS',
        },
        {
          icon: Common.Display,
          title: 'Tampilan Yang Mudah Dipahami',
          body: 'Tingkatkan keseluruhan pengalaman pembayaran dengan memungkinkan pelanggan melakukan pratayang perincian tagihan selama pembayaran.',
        },
      ],
    },
  ],
};
