import { Common } from '@/assets/svgs';
import solutionsFeatureImg from '@/assets/images/contactless-feature.jpg';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of contactless ordering
export const solutionFeatures: SolutionsFeaturesProps = {
  title: 'Kenyamanan Contactless Untuk Pemesanan Yang Mudah',
  features: [
    {
      smallImage: solutionsFeatureImg,
      largeImage: solutionsFeatureImg,
      altText:
        "Customer with phone scans QR for Hubbo POS's table ordering, dynamic service, and order-ahead feature.",
      content: [
        {
          icon: Common.QRCode,
          title: 'Pemesanan QR di Meja',
          body: 'Pemesanan QR di meja memudahkan keseluruhan pengalaman bersantap, memungkinkan pelanggan untuk menjelajahi menu, memesan, dan membayar langsung dari ponsel mereka.',
        },
        {
          icon: Common.DynamicQR,
          title: 'Pemesanan QR Dinamis',
          body: 'Didesain untuk layanan meja restoran, memperlancar operasional, mengurangi kesalahan manual, dan meningkatkan efisiensi',
        },
        {
          icon: Common.Container,
          title: 'Pesan Dulu & Ambil Kemudian',
          body: 'Menawarkan pengalaman bagi pelanggan Anda untuk pesan & bayar di manapun sebelum mengambil orderan',
        },
      ],
    },
  ],
};
