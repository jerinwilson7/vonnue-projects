import filterSmallImage from '@/assets/images/contactless-cta-id-small.png';
import filterLargeImage from '@/assets/images/contactless-cta-id-large.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    "Customer's hand holding credit card near black tablet for Hubbo POS contactless payment.",
  buttonTitle: 'Minta Demo Gratis',
  buttonLink: `/request-demo`,
  title: 'Waktu Perputaran yang Lebih Cepat dan Alur Kerja yang Lebih Lancar',
  body: 'Dengan HUBBO POS, pelanggan bisa dengan mudah menjelajahi menu, memesan, dan membayar sendiri. Ini berarti waktu tunggu yang lebih singkat, berkurangnya proses manual, dan meningkatnya kepuasan pelanggan.',
};
