import { footerBanner } from '@/data/id/common/';
import { SolutionsTemplateProps } from '@/sections/solutions';
import { heroBanner } from './solution-banner';
import { solutionsFilter } from './solution-filter';
import { solutionFeatures } from './solution-features';
import { solutionFilterTwo } from './solution-filter-two';

export const reportingData: SolutionsTemplateProps = {
  heroBanner,
  solutionsFilter,
  solutionsFeaturesVariantOne: solutionFeatures,
  solutionFilterTwo,
  footerBanner,
};
