import filterSmallImage from '@/assets/images/reporting-feature-2.png';
import filterLargeImage from '@/assets/images/reporting-feature-2.png';
import { SolutionFilterTwoProps } from '@/sections/solutions/SolutionFilterTwo';

export const solutionFilterTwo: SolutionFilterTwoProps = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    "Image of Hubbo POS diagnostic page on black tablet with 'Run Diagnostics' button and latest results.",
  title: 'Sistem Analisis',
  openingText:
    'Manfaatkan sistem analisis HUBBO POS, didesain untuk mendeteksi masalah dengan cepat & pemecahannya. Tampilan antarmuka yang mudah dipahami memudahkan proses pemecahan masalah, memungkinkan Anda untuk secara cepat mengidentifikasi dan menyelesaikan masalah terkait POS tanpa harus memiliki keahlian teknis tingkat tinggi.',
  mainText: '',
};
