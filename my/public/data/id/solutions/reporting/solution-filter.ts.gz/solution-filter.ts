import filterSmallImage from '@/assets/images/reporting-cta-id-sm.png';
import filterLargeImage from '@/assets/images/reporting-cta-id-lg.png';
import { SolutionsFilterProps } from '@/sections/solutions/SolutionFilter';

export const solutionsFilter: SolutionsFilterProps = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    'Hubbo POS sales trend graph from 7th Nov to 7th Dec 2023, indicating gross sales, discounts, and bestsellers.',
  buttonTitle: 'Minta Demo Gratis',
  buttonLink: `/request-demo`,
  title: 'Tingkatkan pengambilan keputusan dengan data yang relevan',
  body: 'Dengan wawasan berbasis data HUBBO POS, Anda dapat mengidentifikasi produk yang paling laris, memantau tingkat persediaan, dan merancang promosi sesuai preferensi pribadi pelanggan.',
};
