import { Common } from '@/assets/svgs';
import solutionsFeatureImgSm from '@/assets/images/reporting-feature-1.png';
import solutionsFeatureImgLg from '@/assets/images/reporting-feature-1.png';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of cloud POS
export const solutionFeatures: SolutionsFeaturesProps = {
  title: 'Wawasan berbasis data untuk meningkatkan bisnis Anda',
  features: [
    {
      smallImage: solutionsFeatureImgSm,
      largeImage: solutionsFeatureImgLg,
      altText:
        '25 year old man in white shirt views real-time sales reports on his tablet with Hubbo POS.',
      content: [
        {
          icon: Common.ProgressChartIcon,
          title: 'Aksesibilitas di ujung jari Anda',
          body: 'Pantau terus bisnis Anda dengan data penjualan langsung melalui platform kami yang intuitif: Portal, Aplikasi Bisnis HUBBO, dan aplikasi HUBBO POS.',
        },
        {
          icon: Common.BarCharIcon,
          title: 'Pelaporan real-time',
          body: 'Pantau keuangan bisnis Anda, tren pendapatan, kinerja menu, dan persediaan secara keseluruhan & efisien.',
        },
        {
          icon: Common.PerformanceIcon,
          title: 'Wawasan Data & Kinerja',
          body: 'Telusuri metrik kinerja rinci untuk menemukan peluang pengembangan dalam bisnis Anda.',
        },
      ],
    },
  ],
};
