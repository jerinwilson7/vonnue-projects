import heroSmall from '@/assets/images/integrations-landing-small.jpg';
import heroLarge from '@/assets/images/integrations-landing-large.jpg';
import { Common } from '@/assets/svgs';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const heroBanner: SolutionsTemplateProps['heroBanner'] = {
  pageIndicatorIcon: Common.Integrations,
  pageIndicatorTitle: 'Integrasi',
  bannerTitle:
    'Menyatukan operasional restoran Anda pada satu platform tunggal',
  bannerBody:
    'Integrasi canggih lintas platform pengiriman, pembayaran QRIS, dan lebih banyak lagi',
  heroSmallImage: heroSmall,
  heroLargeImage: heroLarge,
  imageAlt:
    'Restaurant owner in blue apron operates Hubbo POS, highlighting powerful delivery and payment integrations.',
};
