import filterSmallImage from '@/assets/images/integrations-cta-id.png';
import filterLargeImage from '@/assets/images/integrations-cta-id.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    'Webscreen on black tablet showing a list of platforms integrated with Hubbo POS.',
  buttonTitle: 'Minta Demo Gratis',
  buttonLink: `/request-demo`,
  title: 'Satu Perangkat untuk Mendukung Semua Operasi Bisnis Anda',
  body: 'Dengan solusi integrasi canggih, Anda bisa mengelola semua yang Anda butuhkan di satu perangkat tunggal dan memantau bisnis secara efektif.',
};
