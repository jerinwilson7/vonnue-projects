import { footerBanner } from '@/data/id/common/';
import { heroBanner } from './solution-banner';
import { solutionsFilter } from './solution-filter';
import { solutionFeaturesVariantOne } from './solution-features-variant-one';
import { solutionFeaturesVariantTwo } from './solution-features-variant-two';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const integrationsData: SolutionsTemplateProps = {
  heroBanner,
  solutionsFilter,
  solutionsFeaturesVariantOne: solutionFeaturesVariantOne,
  solutionsFeaturesVariantTwo: solutionFeaturesVariantTwo,
  footerBanner,
};
