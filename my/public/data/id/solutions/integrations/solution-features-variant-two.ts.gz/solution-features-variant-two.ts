import { Common } from '@/assets/svgs';
import solutionsFeatureImg1 from '@/assets/images/integrations-id-feature-2.png';
import solutionsFeatureImg2Small from '@/assets/images/integrations-feature-3-small.png';
import solutionsFeatureImg2Large from '@/assets/images/integrations-feature-3-large.png';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of integrations - section two
export const solutionFeaturesVariantTwo: SolutionsFeaturesProps = {
  title: 'Integrasi Dengan Layanan Melebihi dari Pengiriman Makanan',
  backgroundColor: 'bg-background-secondary',
  rowReverseOnOdd: true,
  features: [
    {
      smallImage: solutionsFeatureImg1,
      largeImage: solutionsFeatureImg1,
      altText:
        'Mac laptop surrounded by various payment app icons representing Hubbo POS payment options.',
      content: [
        {
          icon: Common.Payment,
          title: 'Banyak Pilihan Pembayaran',
          body: 'Sistem kami terintegrasi dengan pembayaran QRIS. Tanpa perlu terminal tambahan, cukup gunakan perangkat all-in-one HUBBO POS kita.',
        },
        {
          icon: Common.StreamlinedAccounting,
          title: 'Kelola Keuangan Dengan Mudah',
          body: 'Lancarkan manajemen keuangan dengan integrasi perangkat lunak HUBBO POS. Laporan keuangan Anda tetap terbarui, memungkinkan Anda fokus pada pertumbuhan bisnis.',
        },
      ],
    },
    {
      smallImage: solutionsFeatureImg2Small,
      largeImage: solutionsFeatureImg2Large,
      altText:
        'Chef in white apron updates inventory on white tablet using Hubbo POS.',
      content: [
        {
          icon: Common.SupplyChain,
          title: 'Supply Chain Management',
          body: 'Mempermudah supply chain management dengan sistem inventory cerdas. Kurangi limbah, terima pemberitahuan stok yang menipis, dan lakukan keputusan pembelian terinformasi berdasarkan data real-time.',
        },
        {
          icon: Common.ProgressChartIcon,
          title: 'Informasi Bisnis',
          body: 'Dapatkan informasi bisnis dan akses laporan belanja otomatis untuk mendukung pengambilan keputusan Anda.',
        },
      ],
    },
  ],
};
