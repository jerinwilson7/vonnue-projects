import { Common } from '@/assets/svgs';
import solutionsFeatureImg from '@/assets/images/integrations-feature-1-id.jpg';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of integrations - section one
export const solutionFeaturesVariantOne: SolutionsFeaturesProps = {
  title: 'Sederhanakan Semua Pesanan Anda di Satu Tempat',
  features: [
    {
      smallImage: solutionsFeatureImg,
      largeImage: solutionsFeatureImg,
      altText:
        'Restaurant manager adds a menu item on a black touchscreen tablet using Hubbo POS.',
      content: [
        {
          icon: Common.Restaurant,
          title: 'Dirancang khusus untuk Berbagai Platform Pengiriman Utama',
          body: 'Sistem inovatif kami didesain untuk memenuhi kebutuhan restoran yang mengoperasikan berbagai platform pengiriman makanan, termasuk GrabFood, GoFood, dan ShopeeFood.',
        },
        {
          icon: Common.OrderSyncing,
          title: 'Sinkronisasi Pesanan Otomatis',
          body: 'Dengan HUBBO POS, semua pesanan pengiriman terintegrasi dengan mudah disinkronisasikan tanpa harus melakukan intervensi manual, ini menjamin akurasi dan membuat beban operasional lebih kecil.',
        },
        {
          icon: Common.Menu,
          title: 'Menu Anda Dapat Terus Diperbaharui Dengan Mudah',
          body: 'HUBBO POS menyederhanakan pembaruan menu lintas platform pengiriman maupun offline hanya dengan sekali klik saja.',
        },
      ],
    },
  ],
};
