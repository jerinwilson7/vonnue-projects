import AboutUs from '@/assets/svgs/headerIcons/about-us.svg';
import ContactlessOrdering from '@/assets/svgs/headerIcons/contactless-ordering.svg';
import { Header } from '@/types/common/header';
import Integrations from '@/assets/svgs/headerIcons/integrations.svg';
import NumberCallingSystem from '@/assets/svgs/headerIcons/number-calling-system.svg';
import Reporting from '@/assets/svgs/headerIcons/reporting.svg';
import Vector from '@/assets/svgs/headerIcons/vector.svg';

export const headerListData: Header = {
  solutionsList: [
    {
      id: 1,
      title: 'POS Virtual',
      icon: Vector,
      link: `/solutions/cloud-pos`,
    },
    {
      id: 2,
      title: 'Sistem panggilan nomor',
      icon: NumberCallingSystem,
      link: `/solutions/number-calling-system`,
    },
    {
      id: 3,
      title: 'Pesanan',
      icon: ContactlessOrdering,
      link: `/solutions/contactless-ordering`,
    },
    {
      id: 5,
      title: 'Integrasi',
      icon: Integrations,
      link: `/solutions/integrations`,
    },
    {
      id: 6,
      title: 'Pelaporan',
      icon: Reporting,
      link: `/solutions/reporting`,
    },
  ],
  whyHubboList: [
    {
      id: 1,
      title: 'Tentang Kami',
      icon: AboutUs,
      link: `/about`,
    },
  ],
  contactUsLink: `/contact-us`,
  pricingLink: `/pricing`,
  headerButtonText: 'Mulai',
  headerButtonLink: `/request-demo`,
  requestDemoLink: `/request-demo`,
  requestDemoText: 'Minta Demo Gratis',
  headerLogoLink: `/`,
  solutionsLinkText: 'Solusi',
  plansAndPricingLinkText: 'Harga Paket',
  whyHubboLinkText: 'Mengapa HUBBO?',
  contactUsLinkText: 'Hubungi kami',
  loginLinkText: 'Masuk',
  loginLink: ' https://admin.hubbopos.com/admin/login',
  languageLinkText: 'Language',
};
