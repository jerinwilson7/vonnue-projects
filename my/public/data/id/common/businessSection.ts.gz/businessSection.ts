import { PartnerLogosProps } from '@/sections/common/PartnerLogos';
import { CommonImages } from '@/assets/images';
export const businessSection: PartnerLogosProps = {
  title: 'Mendukung semua jenis bisnis restoran',
  description:
    'Baik Anda mengoperasikan kios tunggal, dapur cloud, layanan cepat, layanan penuh, layanan meja, restoran mewah HUBBO POS memiliki solusi khusus yang disiapkan untuk Anda. ',
  mobileImages: [
    { url: CommonImages.businessLogo1, alt: 'logo1' },
    { url: CommonImages.businessLogo2, alt: 'logo2' },
    { url: CommonImages.businessLogo3, alt: 'logo3' },
    { url: CommonImages.businessLogo4, alt: 'logo4' },
    { url: CommonImages.businessLogo5, alt: 'logo5' },
    { url: CommonImages.businessLogo6, alt: 'logo6' },
    { url: CommonImages.businessLogo7, alt: 'logo7' },
    { url: CommonImages.businessLogo8, alt: 'logo8' },
    { url: CommonImages.businessLogo9, alt: 'logo9' },
  ],
  desktopImages: [
    { url: CommonImages.businessLogo1, alt: 'logo1' },
    { url: CommonImages.businessLogo2, alt: 'logo2' },
    { url: CommonImages.businessLogo3, alt: 'logo3' },
    { url: CommonImages.businessLogo4, alt: 'logo4' },
    { url: CommonImages.businessLogo5, alt: 'logo5' },
    { url: CommonImages.businessLogo6, alt: 'logo6' },
    { url: CommonImages.businessLogo7, alt: 'logo7' },
    { url: CommonImages.businessLogo8, alt: 'logo8' },
    { url: CommonImages.businessLogo9, alt: 'logo9' },
  ],
};
