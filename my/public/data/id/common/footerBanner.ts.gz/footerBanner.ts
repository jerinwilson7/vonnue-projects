import { FooterBannerProps } from '@/sections/common/FooterBanner';

export const footerBanner: FooterBannerProps = {
  heading: 'POS serbaguna untuk restoran Anda',
  mainText: `Optimalkan operasional restoran Anda dan percepat pertumbuhan bisnisnya `,
  buttonText: 'Minta Demo Gratis',
  buttonLink: `/request-demo`,
};

export const footerBannerAbout: FooterBannerProps = {
  heading: 'POS serbaguna untuk restoran Anda',
  mainText: `Were you are operate a standalone kiosk, cloud kitchen, quick service, full service, table service`,
  buttonText: 'Minta Demo Gratis',
  buttonLink: `/request-demo`,
};
