import { chooseYourPlanData } from '../pricing/choose-your-plan';
import { FooterProps } from '@/sections/common/footer';
import { Common } from '@/assets/svgs';

// Links for playstore and appstore
const storeLinks = {
  playStoreLink:
    ' https://play.google.com/store/apps/details?id=com.aliments.biz',
  appStoreLink: 'https://apps.apple.com/sg/app/hubbo-pos-business/id1572230787',
};

export const footerData: FooterProps = {
  navLinks: [
    {
      title: 'Solusi',
      values: [
        { text: 'POS Virtual', url: `/solutions/cloud-pos` },
        {
          text: 'Pesanan',
          url: `/solutions/contactless-ordering`,
        },
        { text: 'Integrasi', url: `/solutions/integrations` },
        { text: 'Pelaporan', url: `/solutions/reporting` },
        {
          text: 'Sistem panggilan nomor',
          url: `/solutions/number-calling-system`,
        },
      ],
    },
    {
      title: 'Harga Paket',
      values: chooseYourPlanData.priceCardData.map(data => ({
        text: data.title,
        url: `/pricing#${data.id}`,
      })),
    },
    {
      title: 'Perusahaan',
      values: [
        { text: 'Tentang Kami', url: `/about` },
        { text: 'Sumber Daya', url: '' },
        { text: 'Cerita Pelanggan', url: '' },
        { text: 'Studi Kasus', url: '' },
      ],
    },
    {
      title: 'Dukungan',
      values: [
        {
          text: 'Pusat Bantuan',
          url: 'https://help.grab.com/merchant/id-id/9643848352665-HUBBO-POS',
        },
        { text: 'Hubungi kami', url: `/contact-us` },
      ],
    },
  ],
  socialMedia: [
    { link: 'https://www.facebook.com/hubbopos.my/', img: Common.FacebookLogo },
    { link: 'https://www.instagram.com/hubbo.my/', img: Common.InstagramLogo },
  ],
  copyright: {
    content: '',
    linkText: 'Pemberitahuan Privasi',
    link: 'https://docs.google.com/document/d/e/2PACX-1vTvbWFdaobxK9c7vU3T_nwrcoIlhRp3tLv1vZjYE1jjyRxgQ85w2ZICGbxhtgw7E0qA3oLARMPJKzAItmTqT74/pub',
  },
  enquiryText: ' Butuh bantuan? Hubungi kami di',
  enquiryLink: 'hello.id@hubbopos.com',
  storeIconsSm: [
    {
      icon: Common.AppStoreSmLink,
      link: storeLinks.appStoreLink,
    },
    {
      icon: Common.GooglePlaySmLink,
      link: storeLinks.playStoreLink,
    },
  ],
  storeIconsMd: [
    {
      icon: Common.AppStoreMdLink,
      link: storeLinks.appStoreLink,
    },
    {
      icon: Common.GooglePlayMdLink,
      link: storeLinks.playStoreLink,
    },
  ],
  storeIconsXl: [
    {
      icon: Common.AppStoreXlLink,
      link: storeLinks.appStoreLink,
    },
    {
      icon: Common.GooglePlayXlLink,
      link: storeLinks.playStoreLink,
    },
  ],
};
