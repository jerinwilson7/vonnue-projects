import testimonialOne from '@/assets/images/testimonial-id-one.jpeg';
import { TestimonialCarousalProps } from '@/components/Testimonial';

export const testimonialsData: TestimonialCarousalProps = {
  title: 'Mengapa 1600+ pemilik restoran menyukai HUBBO POS',
  slide: [
    {
      testimony:
        'Selama pakai HUBBO POS, banyak proses yang jadi lebih simpel dan membantu kelancaran bisnis kami, contohnya saat butuh laporan pendapatan toko tidak harus tarik data satu persatu, begitupun dengan penambahan menu ke aplikasi Grab lebih mudah dipahami tampilannya. Selain itu, HUBBO POS juga bisa diakses dengan HP jadi memudahkan pengecekan harian. Sistem POS yang sangat recommended buat pengusaha F&B! Pokoknya gacor deh!',
      endorserImage: {
        desktopImage: testimonialOne,
        mobileImage: testimonialOne,
      },
      organizationLogo: null,
      endorser: null,
      designation: 'Balista Sushi & Tea',
    },
  ],
};
