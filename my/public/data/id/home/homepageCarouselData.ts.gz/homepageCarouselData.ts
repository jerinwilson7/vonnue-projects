import { SlideProps } from '@/components/home/Slide';
import slideBackgroundOne from '@/assets/images/landing-page-large.jpg';

export const homePageCarouselData: SlideProps[] = [
  {
    title: 'Lancarkan bisnis Anda dengan HUBBO POS',
    description:
      'Kelola pembaruan menu, pesanan di resto, dan pengiriman di semua platform pengiriman utama dengan HUBBO POS.',
    buttonTitle: 'Minta Demo Gratis',
    buttonLink: `/request-demo`,
    slideBackground: slideBackgroundOne,
  },
];
