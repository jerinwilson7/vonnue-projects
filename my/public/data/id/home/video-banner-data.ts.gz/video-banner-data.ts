import thumbnail from '@/assets/images/video-banner-image.png';
import { VideoBannerProps } from '@/sections/home/VideoBanner';

export const videoBannerData: VideoBannerProps = {
  title: 'Platform Operasional Resto yang dapat memfasilitasi kebutuhan Anda',
  subTitle: `Dirancang untuk melayani usaha pribadi kecil-kecilan dan jaringan resto, HUBBO POS adalah kunci untuk membesarkan operasi bisnis Anda serta meningkatkan penjualan secara keseluruhan.`,
  buttonText: 'minta demo gratis',
  buttonLink: `/request-demo`,
  embeddedLink: 'https://vimeo.com/818972488/8832c0010b?ts=0&share=copy',
  thumbnail,
  playButtonText: 'Pelajari tentang HUBBO POS',
};
