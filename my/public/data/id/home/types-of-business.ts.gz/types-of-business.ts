import { PartnerLogosProps } from '@/sections/common/PartnerLogos';
import { businessSection } from '../common';

export const typesOfBusiness: PartnerLogosProps = {
  title: 'Mendukung semua jenis bisnis restoran',
  description:
    'Dari kios kecil, dapur virtual, restoran cepat saji, restoran biasa sampai rumah makan mewah, HUBBO POS menawarkan solusi yang dirancang khusus untuk semua kebutuhan Anda. ',
  mobileImages: businessSection.mobileImages,
  desktopImages: businessSection.desktopImages,
};
