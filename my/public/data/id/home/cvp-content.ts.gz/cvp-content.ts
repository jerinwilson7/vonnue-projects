import { Common } from '@/assets/svgs';
import { CvpProps } from '@/sections/home/Cvp';
import cvpImage from '@/assets/images/solution-filter.png';

export const cvpContents: CvpProps = {
  smallImage: cvpImage,
  largeImage: cvpImage,
  altText:
    'Close-up of tablet with Hubbo POS Dashboard showing sales chart with positive trend highlighted.',
  eyebrowText: 'Sistem POS terkemuka di Indonesia',
  title: 'Satu platform, kendali sepenuhnya',
  description: [
    'Hubbo POS adalah sistem titik penjualan (POS) yang memberikan kendali total terhadap operasi restoran Anda.',
    'Dari pembaruan menu sekali klik hingga pemesanan tanpa sentuhan, dapatkan pengalaman alur kerja yang lancar serta peningkatan efisiensi yang akan membantu Anda mengurangi biaya operasional dan menghadirkan pengalaman pelanggan yang luar biasa.',
  ],
  item: [
    {
      image: Common.Eat,
      title: 'Perbarui menu Anda dengan sekali klik',
      description:
        'Hanya sekali klik untuk memperbarui menu Anda di semua platform restoran dan pengiriman makanan',
    },
    {
      image: Common.People,
      title: 'Kurangi biaya tenaga kerja hingga 35%',
      description:
        'Kurangi kesalahan manual dan dukungan staf yang diperlukan dengan peningkatan automatisasi',
    },
    {
      image: Common.Growth,
      title: 'Tingkatkan penjualan rata-rata hingga 49%',
      description:
        'Pesanan contactless dapat membantu bisnismu meningkatkan penjualan, lho!',
    },
  ],
};
