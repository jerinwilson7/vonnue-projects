import integrationPartnersSm from '@/assets/images/integration-partners-id-sm.png';
import integrationPartnersLg from '@/assets/images/integration-partners-id-lg.png';
import omniChannelSm from '@/assets/images/omni-channel-id-small.png';
import omniChannelLg from '@/assets/images/omni-channel-id-large.png';
import storeOperationsSm from '@/assets/images/store-operations-small.png';
import storeOperationsLg from '@/assets/images/store-operations-large.png';
import customerExperienceSm from '@/assets/images/customer-experience-id-small.png';
import customerExperienceLg from '@/assets/images/customer-experience-id-large.png';
import { TabSectionProps } from '@/sections/home/TailoredSolutions';

export const tailoredSolutions: TabSectionProps = {
  tab: [
    {
      tabTitle: 'Para Mitra',
      image: {
        desktopImage: integrationPartnersLg,
        mobileImage: integrationPartnersSm,
      },
      altText:
        'Restaurant owner in blue apron manages orders and business operations on a tablet with Hubbo POS integration.',
      title: 'Integrasi POS terbaik di kelasnya',
      description:
        'Integrasi kami yang kuat memungkinkan Anda mengelola pengiriman online, pembayaran mobile, dan solusi akuntansi Anda secara lancar dengan satu perangkat.',
      bulletPoints: [
        'Integrasi Pengiriman Makanan Online - GrabFood, ShopeeFood, GoFood',
        'Integrasi Pembayaran eWallet',
        'Integrasi Akuntansi',
      ],
      imagePositionDesktop: 'left',
      imagePositionMobile: 'top',
      buttonText: 'Pelajari lebih lanjut',
      buttonLink: `/solutions/integrations`,
    },
    {
      tabTitle: 'Omni-channel',
      image: {
        desktopImage: omniChannelLg,
        mobileImage: omniChannelSm,
      },
      altText:
        ' A man packing food orders, including an Avocado Tomato Salad, with Hubbo and Grab Food logos.',
      title: 'Perlancar pesanan online dan offline Anda',
      description:
        'Dapatkan pengalaman manajemen pesanan online dan offline yang lancar, operasi dapur yang tanpa masalah, dan wawasan penjualan pengubah permainan yang akan mengubah bisnis Anda.',
      bulletPoints: [
        'Manajemen pesanan Omni-Channel',
        'Sistem Panggilan Nomor Cerdas',
        'Sistem Tampilan Dapur Efisien',
        'Wawasan penjualan Omni-channel',
      ],
      imagePositionDesktop: 'left',
      imagePositionMobile: 'top',
      buttonText: 'Pelajari lebih lanjut',
      buttonLink: `/solutions/number-calling-system`,
    },
    {
      tabTitle: 'Operasi toko',
      image: {
        desktopImage: storeOperationsLg,
        mobileImage: storeOperationsSm,
      },
      altText:
        'A person accessing inventory information on the HUBBO POS system through a tablet at a restaurant.',
      title: 'Didesain untuk menyederhanakan operasi restoran Anda',
      description:
        'Ubah operasi harian restoran Anda dengan perangkat alat kami. Nikmati pengalaman manajemen staf dan manajemen gudang tingkat lanjut yang mudah untuk memperlancar proses, meminimalkan disrupsi, dan menciptakan pengalaman menyantap makanan yang belum pernah ada sebelumnya.',
      bulletPoints: [
        'Antarmuka yang Ramah Pengguna',
        'Manajemen Staf yang Efisien',
        'Diagnosis otomatis masalah yang sering muncul',
        'Pecah, Gabung & Transfer Tabel Meja',
        'Pengeditan Denah Lantai yang Intuitif',
        'Manajemen Gudang',
      ],
      imagePositionDesktop: 'left',
      imagePositionMobile: 'top',
      buttonText: 'Pelajari lebih lanjut',
      buttonLink: `/solutions/cloud-pos`,
    },
    {
      tabTitle: 'Pengalaman pelanggan',
      image: {
        desktopImage: customerExperienceLg,
        mobileImage: customerExperienceSm,
      },
      altText:
        "A happy customer receiving her order through HUBBO POS' contactless ordering.",
      title:
        'Atur pengalaman bersantap yang akan menyenangkan para pelanggan Anda',
      description:
        'Menghadirkan pengalaman Dine-in yang luar biasa untuk memaksimalkan kepuasan pelanggan',
      bulletPoints: [
        'Pemesanan QR Tanpa Sentuhan',
        'Program Loyalitas yang Menarik',
        'Personalisasi Opsi Diskon',
      ],
      imagePositionDesktop: 'left',
      imagePositionMobile: 'top',
      buttonText: 'Pelajari lebih lanjut',
      buttonLink: `/solutions/contactless-ordering`,
    },
  ],
  title: 'Solusi yang dirancang khusus untuk bisnis Anda',
};
