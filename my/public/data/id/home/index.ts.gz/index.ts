import { HomeTemplateProps } from '@/sections/home';
import { footerBanner } from '../common';
import { cvpContents } from './cvp-content';
import { tailoredSolutions } from './tailored-solutions';
import { videoBannerData } from './video-banner-data';
import { testimonialsData } from './testimonial-section';
import { homePageCarouselData } from './homepageCarouselData';
import { typesOfBusiness } from './types-of-business';

export const homePageData: HomeTemplateProps = {
  cvp: cvpContents,
  tailoredSolutions,
  videoBanner: videoBannerData,
  testimonial: testimonialsData,
  footerBanner,
  partnerLogos: typesOfBusiness,
  hero: homePageCarouselData,
};
