import { ContactProps } from '@/sections/contact';

export const heroSection: ContactProps['heroSection'] = {
  message: 'Kami siap membantu Anda',
  description:
    'Tidak dapat menemukan yang Anda cari? Jangan khawatir, kami di sini untuk membantu!',
};
