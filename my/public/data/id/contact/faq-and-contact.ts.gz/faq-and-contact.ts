import { Common } from '@/assets/svgs';
import { FAQAndContactProps } from '@/sections/contact/FAQAndContact';

export const faqAndContact: FAQAndContactProps = {
  title: 'FAQs',
  contactList: [
    {
      target: '_self',
      largeIcon: Common.NewToHubboLg,
      smallIcon: Common.NewToHubboSm,
      title: 'Anda pelanggan baru HUBBO POS?',
      body: 'Jadwalkan demo gratis untuk belajar tentang HUBBO POS.',
      buttonText: 'Daftar untuk Demo',
      link: `/request-demo`,
    },
    {
      target: '_blank',
      largeIcon: Common.SupportLg,
      smallIcon: Common.SupportSm,
      title: 'Anda sudah menjadi pelanggan HUBBO POS?',
      body: 'Cek pusat bantuan kami untuk informasi lebih lanjut.',
      buttonText: 'Pelajari lebih lanjut',
      link: 'https://help.grab.com/merchant/id-id/9643848352665-HUBBO-POS',
    },
  ],
  // Mail containers data
  contactMail: [
    {
      title: 'Untuk pertanyaan-pertanyaan umum :',
      mailTo: 'hello.id@hubbopos.com',
    },
    {
      title: 'Untuk pertanyaan kemitraan atau pemasaran :',
      mailTo: 'marketing.id@hubbopos.com',
    },
  ],
  // FAQ Data
  FAQs: [
    {
      title: 'Apa saja manfaat memilih HUBBO POS?',
      body: 'HUBBO POS membantu restoran skala apa saja tumbuh dan berkembang dengan meminimalisir masalah. Dengan integrasi kami yang kokoh lintas platform pengiriman, pembayaran QRIS, dan lebih banyak lagi, kami menjadikannya mudah untuk Anda dalam menjalankan bisnis secara efisien dan andal dengan menggunakan teknologi penyimpanan virtual. Ini artinya Anda bisa berfokus pada hal-hal yang benar-benar penting - menghadirkan pengalaman Dine-in yang luar biasa bagi para pelanggan',
    },
    {
      title: 'HUBBO POS paling tepat untuk bisnis restoran yang seperti apa?',
      body: `HUBBO POS menawarkan solusi untuk beragam jenis bisnis restoran. Baik Anda mengoperasikan kios mandiri, dapur virtual, layanan cepat, layanan lengkap, layanan meja, atau restoran mewah, kami memiliki solusi yang sempurna untuk Anda. Klik di sini untuk mempelajari lebih banyak tentang penawaran produk kami.`,
    },
    {
      title: 'Apa perbedaan utama antara paket Silver dan Gold?',
      body: `Paket Silver menyediakan langganan perangkat lunak HUBBO POS saja. Sementara dengan Paket Gold, Anda akan mendapatkan perangkat mesinnya juga yang sudah terintegrasi di satu sistem POS tunggal. Tidak perlu lagi memiliki banyak perangkat. Klik di sini untuk mempelajari lebih lanjut tentang Paket Gold`,
    },
    {
      title:
        'Dapatkah saya menggunakan perangkat lunak HUBBO POS dengan perangkat keras POS saya yang sudah ada?',
      body: `Tentu saja! Kami memiliki aneka ragam solusi untuk memenuhi kebutuhan Anda yang berbeda-beda. Klik di sini untuk belajar lebih lanjut.`,
    },
    {
      title: 'Bagaimana struktur pembayaran ditentukan dan ditagih?',
      body: `Paket akan ditagih secara tahunan. Pilih paket Software dan Hardware dan bayar untuk Hardware sekali saja. Setelah itu, baru Anda hanya akan ditagih untuk Software. Klik untuk mempelajari lebih lanjut.`,
    },
  ],
};
