import heroSmall from '@/assets/images/pricing-landing-small.png';
import heroLarge from '@/assets/images/pricing-landing-large.png';
import { Common } from '@/assets/svgs';
import { PricingPageProps } from '@/sections/pricing';

export const pricingHeroBannerData: PricingPageProps['pricingHeroBannerData'] =
  {
    pageIndicatorIcon: Common.Pricing,
    pageIndicatorTitle: 'Harga',
    bannerTitle:
      'Rencana yang fleksibel untuk disesuaikan dengan kebutuhan bisnis Anda',
    bannerBody:
      'Pilih dari aneka paket Software atau dapatkan Software dan Hardware yang sesuai dengan kebutuhan spesifik bisnis Anda.',
    heroSmallImage: heroSmall,
    heroLargeImage: heroLarge,
    imageAlt:
      'Black Hubbo POS device displaying various dishes and a summary of the order.',
  };
