import CTApricingBannerMob from '@/assets/images/pricing-cta-id-small.png';
import CTApricingBannerLg from '@/assets/images/pricing-cta-id-large.png';
import { PricingPageProps } from '@/sections/pricing';

export const pricingBannerData: PricingPageProps['pricingBannerData'] = {
  heading: 'Hubungi kami untuk konsultasi gratis',
  description:
    'Butuh bantuan mengambil keputusan? Konsultasikan dengan para pakar kami yang akan memandu Anda menimbang berbagai solusi berdasarkan kebutuhan Anda. Jadwalkan demo konsultasi gratis hari ini.',
  ctaLabel: 'Minta Demo Gratis',
  ctaLink: `/request-demo`,
  mobileImage: CTApricingBannerMob,
  lgImage: CTApricingBannerLg,
  altText:
    'Black Hubbo POS device displaying various dishes and a summary of the order.',
};
