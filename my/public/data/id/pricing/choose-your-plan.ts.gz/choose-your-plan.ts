import { PricingPageProps } from '@/sections/pricing';

export const chooseYourPlanData: PricingPageProps['chooseYourPlanData'] = {
  title: 'Pilih rencana Anda',
  priceCardData: [
    {
      priceCards: [
        {
          isSelected: false,
          selectedBannerText: 'Paket Rekomendasi',
          planName: 'Bronze',
          pricePrefix: 'IDR',
          price: '1.100.000',
          priceSpanMain: 'dibayar setiap tahun',
          priceSpanSub: 'IDR 99.000 / Deposit',
          buttonText: 'Minta Demo Gratis',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Apa yang Anda dapatkan:',
              bulletPoints: [
                'Transaksi Online',
                'Integrasi E-Wallet & Pembayaran Kartu Kredit',
                'Integrasi Platform Pengiriman',
                'Manajemen Persediaan',
                'Agen Bantuan Langsung Khusus & Pusat Bantuan',
              ],
              itemValue: 'default item',
            },
          ],
        },
        {
          isSelected: true,
          selectedBannerText: 'Paket Rekomendasi',
          planName: 'Silver',
          pricePrefix: 'IDR',
          price: '1.700.000',
          priceSpanMain: 'dibayar setiap tahun',
          priceSpanSub: 'IDR 149.000 / Deposit',
          buttonText: 'Minta Demo Gratis',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Fitur tambahan',
              bulletPoints: [
                'Transaksi Online dan Offline',
                'Pemesanan QR',
                'Manajemen Tabel',
                'Manajemen Multi Outlet',
              ],
              itemValue: 'second item',
            },
            {
              accordionHeader: 'Apa yang Anda dapatkan:',
              bulletPoints: [
                'Transaksi Online',
                'Integrasi E-Wallet & Pembayaran Kartu Kredit',
                'Integrasi Platform Pengiriman',
                'Manajemen Persediaan',
                'Agen Bantuan Langsung Khusus & Pusat Bantuan',
              ],
              itemValue: 'default item',
            },
          ],
        },
      ],
      title: 'Software saja',
      id: 'software-only',
      description: 'Harga sudah termasuk pajak dan pengaturan awal',
      defaultOpen: ['default item', 'second item'],
    },

    {
      priceCards: [
        {
          isSelected: false,
          selectedBannerText: 'Paket Rekomendasi',
          planName: 'Gold Samsung A7 Lite',
          pricePrefix: 'IDR',
          price: '3.900.000',
          priceSpanMain: 'dibayar setiap tahun',
          priceSpanSub: 'IDR 340.000 / Deposit',
          buttonText: 'Minta Demo Gratis',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Fitur tambahan',
              bulletPoints: [
                '1x perangkat Samsung A7 Lite',
                'Transaksi Online dan Offline',
                'Pemesanan QR',
                'Manajemen Tabel',
                'Manajemen Multi Outlet',
              ],
              itemValue: 'default item',
            },
            {
              accordionHeader: 'Apa yang Anda dapatkan:',
              bulletPoints: [
                'Transaksi Online',
                'Integrasi E-Wallet & Pembayaran Kartu Kredit',
                'Integrasi Platform Pengiriman',
                'Manajemen Persediaan',
                'Agen Bantuan Langsung Khusus & Pusat Bantuan',
              ],
              itemValue: 'second item',
            },
          ],
        },
        {
          isSelected: false,
          selectedBannerText: 'Paket Rekomendasi',
          planName: 'Gold Samsung A7 Lite + Printer',
          pricePrefix: 'IDR',
          price: '4.200.000',
          priceSpanMain: 'dibayar setiap tahun',
          priceSpanSub: 'IDR 365.000 / Deposit',
          buttonText: 'Minta Demo Gratis',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Fitur tambahan',
              bulletPoints: [
                '1x perangkat Samsung A7 Lite 1x printer struk bluetooth',
                'Transaksi Online dan Offline',
                'Pemesanan QR',
                'Manajemen Tabel',
                'Manajemen Multi Outlet',
              ],
              itemValue: 'default item',
            },
            {
              accordionHeader: 'Apa yang Anda dapatkan:',
              bulletPoints: [
                'Transaksi Online',
                'Integrasi E-Wallet & Pembayaran Kartu Kredit',
                'Integrasi Platform Pengiriman',
                'Manajemen Persediaan',
                'Agen Bantuan Langsung Khusus & Pusat Bantuan',
              ],
              itemValue: 'second item',
            },
          ],
        },
        {
          isSelected: true,
          selectedBannerText: 'Paket Rekomendasi',
          planName: 'Gold Imin D1',
          pricePrefix: 'IDR',
          price: '5.800.000',
          priceSpanMain: 'dibayar setiap tahun',
          priceSpanSub: 'IDR 499.000 / Deposit',
          buttonText: 'Minta Demo Gratis',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Fitur tambahan',
              bulletPoints: [
                '1x perangkat Imin D1 POS dengan printer struk terintegrasi',
                'Transaksi Online dan Offline',
                'Pemesanan QR',
                'Manajemen Tabel',
                'Manajemen Multi Outlet',
              ],
              itemValue: 'default item',
            },
            {
              accordionHeader: 'Apa yang Anda dapatkan:',
              bulletPoints: [
                'Transaksi Online',
                'Integrasi E-Wallet & Pembayaran Kartu Kredit',
                'Integrasi Platform Pengiriman',
                'Manajemen Persediaan',
                'Agen Bantuan Langsung Khusus & Pusat Bantuan',
              ],
              itemValue: 'second item',
            },
          ],
        },
      ],
      title: 'Software & Hardware',
      id: 'software-&-hardware',
      description:
        'Biaya Hardware cukup sekali pembayaran saja. Harga tidak termasuk pajak dan biaya pengaturan awal.',
      defaultOpen: ['default item', 'second item'],
    },
  ],
};
