import { PricingPageProps } from '@/sections/pricing';

export const chooseYourPlanData: PricingPageProps['chooseYourPlanData'] = {
  title: 'Pilih pelan anda',
  priceCardData: [
    {
      priceCards: [
        {
          isSelected: false,
          selectedBannerText: 'Nilai terbaik',
          planName: 'Silver Basic',
          pricePrefix: 'RM',
          price: '990',
          priceSpanMain: 'Dibilkan setiap tahun',
          priceSpanSub: '',
          buttonText: 'Dapatkan Demo Percuma',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Apa yang anda akan dapat:',
              bulletPoints: [
                'POS Awan Bersepadu',
                'Integrasi Pembayaran E-Dompet & Kad Kredit',
                'Pesanan QR',
                'Kesetiaan Pulangan Tunai',
                'Pengurusan inventori',
                'Integrasi Terminal Pembayaran',
                'Biztory / SQL Accounting / Autocount / Quickbook / Xero / Financio Integration',
                'Pusat Sokongan & Bantuan Ejen Langsung',
              ],
              itemValue: 'default item',
            },
          ],
        },
        {
          isSelected: true,
          selectedBannerText: 'Nilai terbaik',
          planName: 'Gold Basic',
          pricePrefix: 'RM',
          price: '1,490',
          priceSpanMain: 'Dibilkan setiap tahun',
          priceSpanSub: '',
          buttonText: 'Dapatkan Demo Percuma',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Ciri tambahan',
              bulletPoints: ['Penyepaduan Platform Penyampaian'],
              itemValue: 'second item',
            },
            {
              accordionHeader: 'Apa yang anda akan dapat:',
              bulletPoints: [
                'POS Awan Bersepadu',
                'Integrasi Pembayaran E-Dompet & Kad Kredit',
                'Pesanan QR',
                'Kesetiaan Pulangan Tunai',
                'Pengurusan inventori',
                'Integrasi Terminal Pembayaran',
                'Biztory / Perakaunan SQL / Autocount / Quickbook / Xero / Integrasi Kewangan',
                'Pusat Sokongan & Bantuan Ejen Langsung',
              ],
              itemValue: 'default item',
            },
          ],
        },
      ],
      title: 'Perisian Sahaja',
      id: 'software-only',
      description:
        'Kos perkakasan hanya perlu dibayar sekali sahaja. Harga tidak termasuk cukai dan yuran permulaan.',
      defaultOpen: ['default item', 'second item'],
    },
    {
      priceCards: [
        {
          isSelected: false,
          selectedBannerText: 'Nilai terbaik',
          planName: 'Silver Plus',
          pricePrefix: 'RM',
          price: '2,590',
          priceSpanMain: 'Dibayar tahun pertama',
          priceSpanSub: 'RM 990 setahun berikutnya',
          buttonText: 'Dapatkan Demo Percuma',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Ciri tambahan',
              bulletPoints: [
                '1x Peranti POS skrin tunggal dengan Pembaca NFC sedia ada',
              ],
              itemValue: 'default item',
            },
            {
              accordionHeader: 'Apa yang anda akan dapat:',
              bulletPoints: [
                'POS Awan Bersepadu',
                'Integrasi Pembayaran E-Dompet & Kad Kredit',
                'Pesanan QR',
                'Kesetiaan Pulangan Tunai',
                'Pengurusan inventori',
                'Integrasi Terminal Pembayaran',
                'Biztory / Perakaunan SQL / Autocount / Quickbook / Xero / Integrasi Kewangan',
                'Pusat Sokongan & Bantuan Ejen Langsung',
              ],
              itemValue: 'second item',
            },
          ],
        },
        {
          isSelected: false,
          selectedBannerText: 'Nilai terbaik',
          planName: 'Silver Pro',
          pricePrefix: 'RM',
          price: '3,490',
          priceSpanMain: 'Dibayar tahun pertama ',
          priceSpanSub: 'RM 990 setahun berikutnya',
          buttonText: 'Dapatkan Demo Percuma',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Ciri tambahan',
              bulletPoints: [
                '1x Peranti POS dwi skrin dengan Pembaca NFC',
                '1x pengimbas QR',
              ],
              itemValue: 'default item',
            },
            {
              accordionHeader: 'Apa yang anda akan dapat:',
              bulletPoints: [
                'POS Awan Bersepadu',
                'Integrasi Pembayaran E-Dompet & Kad Kredit',
                'Pesanan QR',
                'Kesetiaan Pulangan Tunai',
                'Pengurusan inventori',
                'Integrasi Terminal Pembayaran',
                'Biztory / Perakaunan SQL / Autocount / Quickbook / Xero / Integrasi Kewangan',
                'Pusat Sokongan & Bantuan Ejen Langsung',
              ],
              itemValue: 'second item',
            },
          ],
        },
        {
          isSelected: false,
          selectedBannerText: 'Nilai terbaik',
          planName: 'Gold Plus',
          pricePrefix: 'RM',
          price: '3,090',
          priceSpanMain: 'Dibayar tahun pertama',
          priceSpanSub: 'RM 1,490 setahun berikutnya',
          buttonText: 'Dapatkan Demo Percuma',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Additional features',
              bulletPoints: [
                '1x Peranti POS skrin tunggal dengan Pembaca NFC sedia ada',
                'Integrasi platform pengiriman',
              ],
              itemValue: 'default item',
            },
            {
              accordionHeader: 'What you’ll get:',
              bulletPoints: [
                'POS Awan Bersepadu',
                'Integrasi Pembayaran E-Dompet & Kad Kredit',
                'Pesanan QR',
                'Kesetiaan Pulangan Tunai',
                'Pengurusan inventori',
                'Integrasi Terminal Pembayaran',
                'Biztory / Perakaunan SQL / Autocount / Quickbook / Xero / Integrasi Kewangan',
                'Pusat Sokongan & Bantuan Ejen Langsung',
              ],
              itemValue: 'second item',
            },
          ],
        },
        {
          isSelected: true,
          selectedBannerText: 'Nilai terbaik',
          planName: 'Gold Pro',
          pricePrefix: 'RM',
          price: '3,990',
          priceSpanMain: 'Payable first year; ',
          priceSpanSub: 'RM 1,490 setahun berikutnya',
          buttonText: 'Dapatkan Demo Percuma',
          buttonLink: `/request-demo`,
          accordionItems: [
            {
              accordionHeader: 'Ciri tambahan',
              bulletPoints: [
                '1x Peranti POS dwi skrin dengan Pembaca NFC',
                '1x pengimbas QR',
                'Integrasi platform pengiriman',
              ],
              itemValue: 'default item',
            },
            {
              accordionHeader: 'What you’ll get:',
              bulletPoints: [
                'POS Awan Bersepadu',
                'Integrasi Pembayaran E-Dompet & Kad Kredit',
                'Pesanan QR',
                'Kesetiaan Pulangan Tunai',
                'Pengurusan inventori',
                'Integrasi Terminal Pembayaran',
                'Biztory / Perakaunan SQL / Autocount / Quickbook / Xero / Integrasi Kewangan',
                'Pusat Sokongan & Bantuan Ejen Langsung',
              ],
              itemValue: 'second item',
            },
          ],
        },
      ],
      title: 'Perisian & Perkakasan',
      id: 'software-&-hardware',
      description:
        'Kos perkakasan hanya perlu dibayar sekali sahaja. Harga tidak termasuk cukai dan yuran permulaan.',
      defaultOpen: ['default item'],
    },
  ],
};
