import heroSmall from '@/assets/images/pricing-landing-small.png';
import heroLarge from '@/assets/images/pricing-landing-large.png';
import { Common } from '@/assets/svgs';
import { PricingPageProps } from '@/sections/pricing';

export const pricingHeroBannerData: PricingPageProps['pricingHeroBannerData'] =
  {
    pageIndicatorIcon: Common.Pricing,
    pageIndicatorTitle: 'Penetapan Harga',
    bannerTitle: 'Pelan fleksibel untuk memenuhi keperluan perniagaan anda',
    bannerBody:
      'Pilih daripada pelbagai pakej perisian atau pilih pakej perisian dan perkakasan yang komprehensif untuk memenuhi keperluan perniagaan anda yang unik.',
    heroSmallImage: heroSmall,
    heroLargeImage: heroLarge,
    imageAlt:
      'Black Hubbo POS device displaying various dishes and a summary of the order.',
  };
