import CTApricingBannerMob from '@/assets/images/pricing-cta-small.png';
import CTApricingBannerLg from '@/assets/images/pricing-cta-large.png';
import { PricingPageProps } from '@/sections/pricing';

export const pricingBannerData: PricingPageProps['pricingBannerData'] = {
  heading: 'Bercakap dengan kami untuk \nkonsultasi percuma',
  description:
    'Perlukan bantuan membuat keputusan? Dapatkan bantuan daripada pakar kami yang akan membimbing anda melalui penyelesaian berdasarkan keperluan anda. Minta demo untuk perundingan percuma hari ini.',
  ctaLabel: 'Dapatkan Demo Percuma',
  ctaLink: `/request-demo`,
  mobileImage: CTApricingBannerMob,
  lgImage: CTApricingBannerLg,
  altText:
    'Black Hubbo POS device displaying various dishes and a summary of the order.',
};
