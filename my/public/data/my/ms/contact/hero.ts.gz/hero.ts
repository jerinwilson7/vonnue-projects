import { ContactProps } from '@/sections/contact';

export const heroSection: ContactProps['heroSection'] = {
  message: 'Kami Sedia untuk Membantu',
  description:
    'Tidak menemui apa yang anda cari? Jangan risau, kami sedia membantu!',
};
