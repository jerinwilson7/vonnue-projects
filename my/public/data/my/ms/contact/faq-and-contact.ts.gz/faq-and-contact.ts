import { Common } from '@/assets/svgs';
import { LOCALES } from '@/constants';
import { FAQAndContactProps } from '@/sections/contact/FAQAndContact';

const locale = LOCALES.my;

export const faqAndContact: FAQAndContactProps = {
  title: 'Soalan Lazim',
  contactList: [
    {
      target: '_self',
      largeIcon: Common.NewToHubboLg,
      smallIcon: Common.NewToHubboSm,
      title: 'Baru menggunakan HUBBO POS?',
      body: 'Jadualkan demo percuma untuk mengetahui lebih lanjut tentang HUBBO POS.',
      buttonText: 'Tempah demo',
      link: `/request-demo`,
    },
    {
      target: '_blank',
      largeIcon: Common.SupportLg,
      smallIcon: Common.SupportSm,
      title: 'Pelanggan sedia ada?',
      body: 'Lihat pusat bantuan kami untuk mendapatkan maklumat lanjut.',
      buttonText: 'Ketahui lebih lanjut',
      link: 'https://help.grab.com/merchant/en-my/9643848352665-HUBBO-POS',
    },
  ],
  // Mail containers data
  contactMail: [
    {
      title: 'Untuk pertanyaan am :',
      mailTo: 'hello.my@hubbopos.com',
    },
    {
      title: 'Untuk pertanyaan perkongsian atau pemasaran :',
      mailTo: 'marketing.my@hubbopos.com',
    },
  ],
  // FAQ Data
  FAQs: [
    {
      title: 'Mengapa saya perlu memilih HUBBO POS?',
      body: 'Di HUBBO POS misi kami adalah mudah - untuk membantu restoran tidak kira apa pun jua saiznya berkembang dan maju dengan mudah. Penyepaduan hebat kami merentasi platform penghantaran, saluran pembayaran, kad kredit dan banyak lagi. Ini bermakna anda boleh menjalankan perniagaan anda dengan lebih cekap, sambil menikmati kebolehpercayaan yang tidak berbelah bagi. Dan anda boleh memberikan sepenuh tumpuan pada perkara yang penting- menyediakan pengalaman makan yang luar biasa untuk pelanggan anda.',
    },
    {
      title: 'Apakah jenis perniagaan F&B yang sesuai untuk HUBBO POS?',
      body: `Sama ada anda mengendalikan kiosk kendiri, dapur awan, perkhidmatan pantas, perkhidmatan penuh, perkhidmatan meja, sajian mewah - HUBBO POS mempunyai penyelesaian untuk anda. Klik di sini untuk <a href="/${locale}/solutions/cloud-pos"><u>mengetahui tentang</u></a> penyelesaian produk kami.`,
    },
    {
      title: 'Apakah perbezaan utama antara pakej Silver dan Gold??',
      body: `Dengan HUBBO POS Gold, anda akan dapat menyepadukan dengan platform penghantaran makanan dan menerima pesanan penghantaran pada 1 sistem POS tunggal. Ucapkan selamat tinggal kepada menguruskan berbilang peranti! \n\nLebih-lebih lagi, anda akan dapat mengemas kini menu anda merentasi semua platform penghantaran dengan hanya 1 klik. Menjimatkan masa dan usaha anda.\n\nKlik di sini <a href="/${locale}/pricing"><u>untuk mengetahui</u></a> lebih lanjut.`,
    },
    {
      title:
        'Saya sudah mempunyai perkakasan POS sedia ada. Bolehkah saya memilih hanya perisian?',
      body: `Sudah tentu! Kami mempunyai pelbagai penyelesaian untuk memenuhi keperluan anda yang berbeza. Klik di sini <a href="/${locale}/pricing"><u>untuk mengetahui</u></a> lebih lanjut.`,
    },
    {
      title: 'Bagaimanakah pembayaran dibilkan?',
      body: `Pakej kami pada masa ini dibilkan secara pendahuluan dan tahunan. Jika anda memilih pilihan Perisian dan Perkakasan, anda hanya perlu membayar Perkakasan sekali sahaja pada permulaannya. Pengebilan seterusnya adalah untuk Perisian sahaja. Klik di sini <a href="/${locale}/pricing"><u>untuk mengetahui</u></a> lebih lanjut.</u></a>`,
    },
  ],
};
