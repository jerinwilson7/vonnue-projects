import { chooseYourPlanData } from '../pricing/choose-your-plan';
import { FooterProps } from '@/sections/common/footer';
import { Common } from '@/assets/svgs';

// Links for playstore and appstore
const storeLinks = {
  playStoreLink:
    ' https://play.google.com/store/apps/details?id=com.aliments.biz',
  appStoreLink: 'https://apps.apple.com/sg/app/hubbo-pos-business/id1572230787',
};

export const footerData: FooterProps = {
  navLinks: [
    {
      title: 'Penyelesaian',
      values: [
        { text: 'POS awan', url: `/solutions/cloud-pos` },
        { text: 'Kesetiaan', url: `/solutions/loyalty` },
        {
          text: 'Pesanan tanpa sentuh',
          url: `/solutions/contactless-ordering`,
        },
        { text: 'Integrasi', url: `/solutions/integrations` },
        { text: 'Pelaporan', url: `/solutions/reporting` },
        {
          text: 'Sistem panggilan nombor',
          url: `/solutions/number-calling-system`,
        },
      ],
    },
    {
      title: 'Pelan & Harga',
      values: chooseYourPlanData.priceCardData.map(data => ({
        text: data.title,
        url: `/pricing#${data.id}`,
      })),
    },
    {
      title: 'Syarikat',
      values: [{ text: 'Tentang kami', url: `/about` }],
    },
    {
      title: 'Sokongan',
      values: [
        {
          text: 'Pusat Bantuan',
          url: 'https://help.grab.com/merchant/en-my/9643848352665-HUBBO-POS',
        },
        { text: 'Hubungi Kami', url: `/contact-us` },
      ],
    },
  ],
  socialMedia: [
    { link: 'https://www.facebook.com/hubbopos.my/', img: Common.FacebookLogo },
    { link: 'https://www.instagram.com/hubbo.my/', img: Common.InstagramLogo },
  ],
  copyright: {
    content: '',
    linkText: 'Notis privasi',
    link: 'https://docs.google.com/document/d/e/2PACX-1vTvbWFdaobxK9c7vU3T_nwrcoIlhRp3tLv1vZjYE1jjyRxgQ85w2ZICGbxhtgw7E0qA3oLARMPJKzAItmTqT74/pub',
  },
  enquiryText: 'Perlukan bantuan? Hubungi kami di',
  enquiryLink: 'hello.my@hubbopos.com',
  storeIconsSm: [
    {
      icon: Common.AppStoreSmLink,
      link: storeLinks.appStoreLink,
    },
    {
      icon: Common.GooglePlaySmLink,
      link: storeLinks.playStoreLink,
    },
  ],
  storeIconsMd: [
    {
      icon: Common.AppStoreMdLink,
      link: storeLinks.appStoreLink,
    },
    {
      icon: Common.GooglePlayMdLink,
      link: storeLinks.playStoreLink,
    },
  ],
  storeIconsXl: [
    {
      icon: Common.AppStoreXlLink,
      link: storeLinks.appStoreLink,
    },
    {
      icon: Common.GooglePlayXlLink,
      link: storeLinks.playStoreLink,
    },
  ],
};
