import AboutUs from '@/assets/svgs/headerIcons/about-us.svg';
import ContactlessOrdering from '@/assets/svgs/headerIcons/contactless-ordering.svg';
import { Header } from '@/types/common/header';
import Integrations from '@/assets/svgs/headerIcons/integrations.svg';
import Loyalty from '@/assets/svgs/headerIcons/loyalty.svg';
import NumberCallingSystem from '@/assets/svgs/headerIcons/number-calling-system.svg';
import Reporting from '@/assets/svgs/headerIcons/reporting.svg';
import Vector from '@/assets/svgs/headerIcons/vector.svg';

export const headerListData: Header = {
  solutionsList: [
    {
      id: 1,
      title: 'POS awan',
      icon: Vector,
      link: `/solutions/cloud-pos`,
    },
    {
      id: 2,
      title: 'Sistem panggilan nombor',
      icon: NumberCallingSystem,
      link: `/solutions/number-calling-system`,
    },
    {
      id: 3,
      title: 'Pesanan tanpa sentuh',
      icon: ContactlessOrdering,
      link: `/solutions/contactless-ordering`,
    },
    {
      id: 4,
      title: 'Kesetiaan',
      icon: Loyalty,
      link: `/solutions/loyalty`,
    },
    {
      id: 5,
      title: 'Integrasi',
      icon: Integrations,
      link: `/solutions/integrations`,
    },
    {
      id: 6,
      title: 'Pelaporan',
      icon: Reporting,
      link: `/solutions/reporting`,
    },
  ],
  whyHubboList: [
    {
      id: 1,
      title: 'Tentang kami',
      icon: AboutUs,
      link: `/about`,
    },
  ],
  contactUsLink: `/contact-us`,
  pricingLink: `/pricing`,
  headerButtonText: 'Mulakan',
  headerButtonLink: `/request-demo`,
  requestDemoLink: `/request-demo`,
  requestDemoText: 'Request Free Demo',
  headerLogoLink: `/`,
  solutionsLinkText: 'Penyelesaian',
  plansAndPricingLinkText: 'Pelan & Harga',
  whyHubboLinkText: 'Kenapa Hubbo',
  contactUsLinkText: 'Hubungi Kami',
  loginLinkText: 'Log masuk',
  loginLink: ' https://admin.hubbopos.com/admin/login',
  languageLinkText: 'Bahasa',
};
