import { FooterBannerProps } from '@/sections/common/FooterBanner';

export const footerBanner: FooterBannerProps = {
  heading: 'POS semua dalam satu untuk restoran anda',
  mainText: `Perkemaskan operasi F&B anda dan pertingkatkan pertumbuhan perniagaan anda`,
  buttonText: 'Dapatkan Demo Percuma',
  buttonLink: `/request-demo`,
};