import { LogoContainerProps } from '@/components/request-demo';
import { imagesLg } from '../common/marqueeImages';

export const logoContainerData: LogoContainerProps = {
  title: 'Memperkasakan semua jenis perniagaan F&B',
  images: imagesLg,
};
