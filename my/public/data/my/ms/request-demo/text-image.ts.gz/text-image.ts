import { TextImageContainerProps } from '@/components/request-demo';

export const textImageData: TextImageContainerProps = {
  textContent: {
    header: 'Alami kuasa penyelesaian POS semua dalam satu',
    bulletPointsHeader: 'Jadualkan demo dengan HUBBO POS hari ini.',
    bulletPoints: [
      'Kemas kini menu anda dengan satu klik',
      'Mengurangkan kos buruh hingga 35%',
      'Lihat peningkatan hingga 49% dalam purata saiz tiket dengan pesanan tanpa sentuh',
    ],
  },
  pricingImage: {
    startFromLabel: 'Serendah',
    amount: 'RM2.75',
    perDayLabel: '/hari',
    altText:
      'Close-up of a tablet with a Hubbo POS menu on it, sitting on a wooden table.',
  },
};
