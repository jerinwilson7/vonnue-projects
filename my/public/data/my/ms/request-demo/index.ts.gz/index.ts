import { RequestPageProps } from '@/sections';
import { heroData } from './hero';

export const requestDemoPageData: RequestPageProps = {
  hero: heroData,
};
