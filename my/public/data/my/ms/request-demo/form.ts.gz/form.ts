import FormSuccess from '@/assets/images/form-success.svg';
import { FormProps } from '@/components/request-demo/Form';

export const formData: FormProps = {
  successData: {
    title: 'Terima kasih atas pertanyaan anda!',
    description:
      'Salah seorang staf HUBBO POS kami akan menghubungi anda dalam masa 3 hari bekerja yang berikutnya.',
    image: FormSuccess,
  },
  validationMessages: {
    fullName: {
      required: 'Ini diperlukan',
      max: 'Nama hendaklah sekurang-kurangnya 80 aksara',
    },
    storeName: { required: 'Ini diperlukan' },
    phoneNumber: {
      required: 'Padang tiada',
      typeError: 'Format tidak sah',
    },
    emailAddress: {
      required: 'Padang tiada',
      typeError: 'Format tidak sah',
    },
    numberOfOutlets: {
      required: 'Padang tiada',
      typeError: 'Format tidak sah',
      min: 'Ini mestilah lebih besar daripada atau sama dengan 0',
      max: 'Ini mestilah kurang daripada atau sama dengan 100',
    },
    city: { required: 'Ini diperlukan' },
    form: {
      submittedWithoutTouching: 'Ini diperlukan',
      submissionError: 'Ada yang tidak kena! Bukan salah anda, sila cuba lagi',
    },
  },
  ctaText: 'Dapatkan Demo Percuma',
  privacyPolicy: {
    text: 'Dengan menghantar, anda dengan ini membenarkan Hubbo untuk mengumpulkan, menggunakan, mendedahkan dan juga memproses maklumat yang diberikan bagi memberikan kefahaman yang lebih baik kepada anda tentang perkhidmatan Hubbi (termasuk mengirimkan tawaran, promosi, surat berita dan komunikasi pemasaran lain yang berkaitan kepada anda dan menghubungi anda untuk berkongsi lebih lanjut tentang perkhidmatan tersebut), menjalankan analisis pasaran dan hal-hal pentadbiran yang berkaitan menurut Polisi Privasi Hubbo. Anda boleh berhenti melanggan pada bila-bila masa melalui saluran-saluran yang disediakan dalam komunikasi ini.',
    linkText: 'Notis privasi',
  },
  formFieldLabels: {
    fullName: 'Nama',
    storeName: 'Nama kedai',
    phoneNumber: 'Nombor telefon',
    emailAddress: 'Alamat e-mel',
    numberOfOutlets: 'Bilangan cawangan',
    city: 'Bandar',
  },
};
