import { AboutPageProps } from '@/sections/about';

export const grabBanner: AboutPageProps['grabBanner'] = {
  title: 'HUBBO POS, Rakan Kongsi Pilihan Grab',
  description:
    'Sebagai rakan kongsi POS Pilihan Grab, HUBBO POS menyasarkan untuk membantu GrabFood menavigasi proses penyepaduan penghantaran dengan mudah, dan meletakkan diri mereka untuk kejayaan yang berterusan dalam landskap perniagaan yang sentiasa berkembang.',
  altText:
    'Male restaurant owner in white shirt and black apron hands over food parcel to Grab driver, showcasing Hubbo POS partnership.',
};
