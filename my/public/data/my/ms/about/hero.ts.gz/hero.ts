import { AboutPageProps } from '@/sections/about';

export const hero: AboutPageProps['hero'] = {
  chipText: 'Tentang Kami',
  title: 'kami membantu perniagaan F&B berkembang di Asia Tenggara',
  description:
    'Sistem HUBBO POS kami dibina untuk menjadi sekutu yang teguh untuk menyokong operasi perniagaan pada setiap langkah, membolehkan restoran menumpukan pada penyediaan pengalaman makan yang luar biasa.',
};
