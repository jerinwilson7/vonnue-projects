import { AboutPageProps } from '@/sections/about';

export const missionVision: AboutPageProps['missionVision'] = {
  mission: {
    eyebrow: 'Misi kami',
    title: 'Memperkasakan perniagaan F&B semua saiz',
    description: `Misi kami adalah untuk memperkasakan perniagaan F&B dengan penyelesaian yang inovatif untuk mengendalikan dan meningkatkan perniagaan mereka dengan mudah.`,
    altText:
      'Happy female restaurant owner and Hubbo POS customer in kitchen with cap, holding a white cup.',
  },
  vision: {
    eyebrow: 'Visi kami',
    title: 'Ubah Perniagaan F&B dengan Pengalaman Saluran Pelbagai luar biasa',
    description: `Visi kami adalah untuk merevolusikan industri F&B dengan menyampaikan platform Saluran Pelbagai luar biasa dengan teknologi canggih, antara muka mesra pengguna dan integrasi saluran pintar.`,
    altText:
      'Restaurant owner at service desk addressing a customer with Hubbo POS interface on a tablet.',
  },
};
