import heroSmall from '@/assets/images/loyalty-landing-sm.jpg';
import heroLarge from '@/assets/images/loyalty-landing-lg.jpg';
import { Common } from '@/assets/svgs';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const heroBanner: SolutionsTemplateProps['heroBanner'] = {
  pageIndicatorIcon: Common.Loyalty,
  pageIndicatorTitle: 'Kesetiaan',
  bannerTitle: 'Menangi kembali hati pelanggan dengan Kesetiaan Pulangan Tunai',
  bannerBody:
    'Cara lebih bijak untuk memberi ganjaran kepada pelanggan dan mengembangkan perniagaan anda.',
  heroSmallImage: heroSmall,
  heroLargeImage: heroLarge,
  imageAlt:
    'A happy customer receiving her order through Hubbo POS contactless ordering.',
};
