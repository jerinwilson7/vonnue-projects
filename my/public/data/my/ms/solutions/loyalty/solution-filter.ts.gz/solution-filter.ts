import filterSmallImage from '@/assets/images/loyalty-cta-small.png';
import filterLargeImage from '@/assets/images/loyalty-cta-large.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    "Couple gets a 25% discount on female's mobile, served by manager in yellow with Hubbo POS.",
  buttonTitle: 'Dapatkan Demo Percuma',
  buttonLink: `//request-demo`,
  title: 'Ganjaran Pelanggan Sedia Ada untuk Memandu Ulangan',
  body: 'Tingkatkan jualan dan kesetiaan pelanggan anda dengan ciri Kesetiaan Pulangan Tunai HUBBO POS. Ganjaran secara automatik kepada pelanggan dengan insentif pulangan tunai untuk membawa pelanggan kembali ke kedai.',
};
