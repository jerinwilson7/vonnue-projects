import { Common } from '@/assets/svgs';
import solutionsFeatureImg1 from '@/assets/images/loyalty-feature1.png';
import solutionsFeatureImg2Sm from '@/assets/images/loyalty-feature-2-sm.png';
import solutionsFeatureImg2Lg from '@/assets/images/loyalty-feature-2-lg.png';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of loyalty
export const solutionFeatures: SolutionsFeaturesProps = {
  title: 'Kembangkan Perniagaan Anda dengan Ganjaran Pulangan Tunai',
  features: [
    {
      smallImage: solutionsFeatureImg1,
      largeImage: solutionsFeatureImg1,
      altText:
        'Image of a 6-column Hubbo POS interface for enhancing customer management and retention.',
      content: [
        {
          icon: Common.Bag,
          title: 'Meningkatkan penglibatan pelanggan',
          body: 'Program kesetiaan kami menggunakan kaedah yang terbukti untuk menarik penyertaan pelanggan tanpa bergantung pada penjualan staf, menetapkan HUBBO POS selain daripada program kesetiaan lain.',
        },
        {
          icon: Common.CusomterRetention,
          title: 'Dorong pengekalan pelanggan',
          body: 'Dorong pembelian berulang melalui ganjaran pulangan tunai automatik untuk pelanggan sedia ada.',
        },
      ],
    },
    {
      smallImage: solutionsFeatureImg2Sm,
      largeImage: solutionsFeatureImg2Lg,
      altText:
        'Restaurant owner serves a customer on a laptop, with a menu blackboard and Hubbo POS customer insights.',
      content: [
        {
          icon: Common.Graph,
          title: 'Cerapan pelanggan berkuasa',
          body: 'Dapatkan cerapan yang mendalam tentang corak perbelanjaan pelanggan untuk meningkatkan strategi perniagaan anda.',
        },
        {
          icon: Common.WinbackCustomer,
          title: 'Menangi kembali hati pelanggan',
          body: 'Tarik kembali dan menangi semula hati pelanggan dengan SMS, WhatsApp dan Facebook.',
        },
      ],
    },
  ],
};
