import { SolutionsTemplateProps } from '@/sections/solutions';

const stepsToPay = [
  { step: '1', text: 'Pelanggan membuat pembayaran' },
  { step: '2', text: 'POS mencetak invois dengan QR tunai' },
  { step: '3', text: 'Pelanggan mengimbas QR untuk menuntut tunai' },
  { step: '4', text: 'Pelanggan melawat semula sebelum tamat tempoh tunai' },
];

export const paymentSteps: SolutionsTemplateProps['paymentSteps'] = {
  title: 'Proses langkah demi langkah',
  stepsToPay: stepsToPay,
};
