import { Common } from '@/assets/svgs';
import solutionsFeatureImgSm from '@/assets/images/reporting-feature-1.png';
import solutionsFeatureImgLg from '@/assets/images/reporting-feature-1.png';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of cloud POS
export const solutionFeatures: SolutionsFeaturesProps = {
  title: 'Cerapan terdorong data untuk meningkatkan perniagaan anda',
  features: [
    {
      smallImage: solutionsFeatureImgSm,
      largeImage: solutionsFeatureImgLg,
      altText:
        '25 year old man in white shirt views real-time sales reports on his tablet with Hubbo POS.',
      content: [
        {
          icon: Common.ProgressChartIcon,
          title: 'Kemudahan akses di hujung jari',
          body: 'Pantau perniagaan anda dengan data jualan langsung yang boleh diakses melalui platform intuitif kami: Portal, Aplikasi Perniagaan HUBBO dan aplikasi HUBBO POS.',
        },
        {
          icon: Common.BarCharIcon,
          title: 'Pelaporan masa nyata',
          body: 'Pantau kewangan perniagaan anda, aliran hasil, prestasi menu dan inventori keseluruhan dengan cekap.',
        },
        {
          icon: Common.PerformanceIcon,
          title: 'Data dan cerapan prestasi',
          body: 'Selami metrik prestasi terperinci untuk menentukan peluang peningkatan untuk perniagaan anda.',
        },
      ],
    },
  ],
};
