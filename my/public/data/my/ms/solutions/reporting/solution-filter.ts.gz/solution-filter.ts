import filterSmallImage from '@/assets/images/reporting-cta-sm.png';
import filterLargeImage from '@/assets/images/reporting-cta-lg.png';
import { SolutionsFilterProps } from '@/sections/solutions/SolutionFilter';

export const solutionsFilter: SolutionsFilterProps = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    'Hubbo POS sales trend graph from 7th Nov to 7th Dec 2023, indicating gross sales, discounts, and bestsellers.',
  buttonTitle: 'Dapatkan Demo Percuma',
  buttonLink: `//request-demo`,
  title: 'Tingkatkan keputusan dengan data berkesan',
  body: 'Dengan cerapan terdorong data HUBBO POS, anda boleh mengenal pasti produk paling laris, memantau tahap inventori dan menyesuaikan promosi mengikut keutamaan pelanggan individu',
};
