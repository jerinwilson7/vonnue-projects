import heroSmall from '@/assets/images/reporting-landing-small.jpg';
import heroLarge from '@/assets/images/reporting-landing-large.jpg';
import { Common } from '@/assets/svgs';
import { SolutionAndPricingHeroBannerProps } from '@/sections/common/Hero';

export const heroBanner: SolutionAndPricingHeroBannerProps = {
  pageIndicatorIcon: Common.Reporting,
  pageIndicatorTitle: 'Pelaporan',
  bannerTitle: 'Cerapan dan Pelaporan Perniagaan Lanjutan',
  bannerBody:
    'Perkasakan keputusan perniagaan anda dengan laporan masa nyata daripada Sistem POS HUBBO.',
  heroSmallImage: heroSmall,
  heroLargeImage: heroLarge,
  imageAlt:
    'Male and female analyzing business reports on a tablet with Hubbo POS, pleased with the analytics displayed.',
};
