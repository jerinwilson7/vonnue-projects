import filterSmallImage from '@/assets/images/reporting-feature-2.png';
import filterLargeImage from '@/assets/images/reporting-feature-2.png';
import { SolutionFilterTwoProps } from '@/sections/solutions/SolutionFilterTwo';

export const solutionFilterTwo: SolutionFilterTwoProps = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    "Image of Hubbo POS diagnostic page on black tablet with 'Run Diagnostics' button and latest results.",
  title: 'Alat diagnosis',
  openingText:
    'Alami kuasa alat diagnosis HUBBO POS kami, direka untuk pengesanan isu pantas dan penyelesaian masalah layan diri. Antara muka mesra pengguna kami memudahkan proses penyelesaian masalah, membolehkan anda mengenal pasti dan menyelesaikan isu berkaitan POS dengan cepat tanpa kepakaran teknikal yang meluas.',
  mainText: '',
};
