import filterSmallImage from '@/assets/images/contactless-cta-small.png';
import filterLargeImage from '@/assets/images/contactless-cta-large.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    "Customer's hand holding credit card near black tablet for Hubbo POS contactless payment.",
  buttonTitle: 'Dapatkan Demo Percuma',
  buttonLink: `/request-demo`,
  title: 'Masa Pusing Pantas dan Aliran Kerja Lebih Lancar',
  body: 'Dengan HUBBO POS, pelanggan boleh melayari menu dengan mudah, membuat pesanan, dan membuat pembayaran sendiri. Ini bermaksud masa menunggu yang lebih singkat, pengurangan kesesakan, dan peningkatan kepuasan pelanggan.',
};
