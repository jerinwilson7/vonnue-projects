import heroSmall from '@/assets/images/contactless-landing-sm.jpg';
import heroLarge from '@/assets/images/contactless-landing-large.jpg';
import { Common } from '@/assets/svgs';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const heroBanner: SolutionsTemplateProps['heroBanner'] = {
  pageIndicatorIcon: Common.ContactlessOrdering,
  pageIndicatorTitle: 'Pesanan Tanpa Sentuhan',
  bannerTitle: 'Pesanan Tanpa Sentuhan Dipermudahkan',
  bannerBody:
    'Minimumkan masa menunggu dan utamakan pengalaman memesan pelanggan melalui pesanan tanpa sentuh',
  heroSmallImage: heroSmall,
  heroLargeImage: heroLarge,
  imageAlt:
    'Customer scans QR code with mobile for Hubbo POS contactless ordering.',
};
