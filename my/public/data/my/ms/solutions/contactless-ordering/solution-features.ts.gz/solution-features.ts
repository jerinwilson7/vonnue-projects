import { Common } from '@/assets/svgs';
import solutionsFeatureImg from '@/assets/images/contactless-feature.jpg';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of contactless ordering
export const solutionFeatures: SolutionsFeaturesProps = {
  title: 'Kemudahan Tanpa Sentuhan Untuk Pesanan Yang Mudah',
  features: [
    {
      smallImage: solutionsFeatureImg,
      largeImage: solutionsFeatureImg,
      altText:
        "Customer with phone scans QR for Hubbo POS's table ordering, dynamic service, and order-ahead feature.",
      content: [
        {
          icon: Common.QRCode,
          title: 'Pesanan QR Meja',
          body: 'Pesanan QR Meja memudahkan keseluruhan pengalaman menjamu selera, membolehkan pelanggan mambaca menu, membuat pesanan dan membayar terus daripada telefon pintar mereka.',
        },
        {
          icon: Common.DynamicQR,
          title: 'Pesanan QR Dinamik',
          body: 'Direka untuk F&B perkhidmatan meja, ia menyelaraskan operasi, mengurangkan ralat manual dan meningkatkan kecekapan.',
        },
        {
          icon: Common.Container,
          title: 'Pesan Awal & Pickup',
          body: 'Menawarkan pengalaman Grab & Go yang tulen, membolehkan pelanggan anda memesan dan membayar lebih awal.',
        },
      ],
    },
  ],
};
