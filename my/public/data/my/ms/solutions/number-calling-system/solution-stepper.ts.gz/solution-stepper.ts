import { SolutionsTemplateProps } from '@/sections/solutions';

const stepsToPay = [
  { step: '1', text: 'Restoran menerima tempahan' },
  { step: '2', text: "Pesanan dipaparkan dalam 'Menyediakan'" },
  { step: '3', text: 'Makanan sudah siap' },
  { step: '4', text: 'Pesanan dikemas kini sedia untuk dikumpulkan' },
];

export const paymentSteps: SolutionsTemplateProps['paymentSteps'] = {
  title: 'Proses langkah demi langkah',
  stepsToPay: stepsToPay,
};
