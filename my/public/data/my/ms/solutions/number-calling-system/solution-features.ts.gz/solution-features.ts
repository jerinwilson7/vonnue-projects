import { Common } from '@/assets/svgs';
import solutionsFeatureImg from '@/assets/images/reporting-feature.jpg';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of number calling system
export const solutionFeatures: SolutionsFeaturesProps = {
  title: 'Meningkatkan kecekapan aliran kerja dan produktiviti keseluruhan',
  features: [
    {
      smallImage: solutionsFeatureImg,
      largeImage: solutionsFeatureImg,
      altText:
        'Man packing Avocado Tomato Salad among 7 Hubbo POS differentiated orders, showcasing order efficiency.',
      content: [
        {
          icon: Common.SmartCallingSytem,
          title: 'Pengumpulan Item Automatik',
          body: 'Kurangkan masa penyediaan dengan pengumpulan item yang cekap dan penyegerakan pesanan automatik.',
        },
        {
          icon: Common.AdvancedDisplaySystem,
          title: 'Bezakan pesanan mengikut platform',
          body: 'Sistem paparan tiket unik kami secara automatik memisahkan pesanan daripada platform penghantaran dan makan di kedai, mengurangkan masa menunggu keseluruhan.',
        },
      ],
    },
  ],
};
