import filterSmallImage from '@/assets/images/reporting-cta-small.png';
import filterLargeImage from '@/assets/images/reporting-cta-large.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    'Restaurant owner serving a customer in an orange t-shirt, facilitated by Hubbo POS.',
  buttonTitle: 'Dapatkan Demo Percuma',
  buttonLink: `/request-demo`,
  title: 'Semua Operasi Restoran Anda Sepintas lalu',
  body: 'Sekali pandang, anda akan mendapat status pesanan penghantaran, ambil sendiri dan makan di kedai yang disusun dengan kemas mengikut platform untuk meningkatkan produktiviti restoran anda.',
};
