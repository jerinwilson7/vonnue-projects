import heroSmall from '@/assets/images/number-calling-landing-sm.png';
import heroLarge from '@/assets/images/number-calling-landing-large.png';
import { Common } from '@/assets/svgs';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const heroBanner: SolutionsTemplateProps['heroBanner'] = {
  pageIndicatorIcon: Common.NumberCallingSystem,
  pageIndicatorTitle: 'Sistem Panggilan Nombor',
  bannerTitle: 'Sistem Panggilan Nombor Pintar',
  bannerBody:
    'Tingkatkan kelajuan perkhidmatan anda dengan menggunakan sistem pengurusan barisan pintar HUBBO POS.',
  heroSmallImage: heroSmall,
  heroLargeImage: heroLarge,
  imageAlt:
    'Giant TV shows Hubbo POS kitchen display system for improved service speed and queue management.',
};
