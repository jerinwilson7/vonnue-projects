import filterSmallImage from '@/assets/images/integrations-cta.png';
import filterLargeImage from '@/assets/images/integrations-cta.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    'Webscreen on black tablet showing a list of platforms integrated with Hubbo POS.',
  buttonTitle: 'Dapatkan Demo Percuma',
  buttonLink: `/request-demo`,
  title: 'Satu Peranti untuk Menguasakan Semua Operasi Perniagaan Anda',
  body: 'Dengan penyelesaian penyepaduan kami yang berkuasa, anda boleh mengurus semua yang anda perlukan di satu peranti dan mengendalikan perniagaan anda dengan mudah.',
};
