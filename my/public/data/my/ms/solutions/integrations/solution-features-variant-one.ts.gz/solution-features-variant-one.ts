import { Common } from '@/assets/svgs';
import solutionsFeatureImg from '@/assets/images/integrations-feature-1.jpg';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of integrations - section one
export const solutionFeaturesVariantOne: SolutionsFeaturesProps = {
  title: 'Permudahkan Semua Pesanan Anda di Satu Tempat',
  features: [
    {
      smallImage: solutionsFeatureImg,
      largeImage: solutionsFeatureImg,
      altText:
        'Restaurant manager adds a menu item on a black touchscreen tablet using Hubbo POS.',
      content: [
        {
          icon: Common.Restaurant,
          title: 'Disesuaikan untuk Platform Penghantaran Utama',
          body: 'Sistem inovatif kami direka untuk memenuhi keperluan restoran yang beroperasi di pelbagai platform penghantaran makanan, termasuk GrabFood, FoodPanda dan ShopeeFood.',
        },
        {
          icon: Common.OrderSyncing,
          title: 'Penyegerakan Pesanan Automatik',
          body: 'Dengan HUBBO POS, semua pesanan penghantaran  bersepadu disegerakkan  dengan mudah tanpa memerlukan campur tangan manual,  menjamin ketepatan dan kurang overhed operasi.',
        },
        {
          icon: Common.Menu,
          title: 'Pastikan menu anda dikemas kini dengan mudah',
          body: 'Pastikan menu anda dikemas kini dengan mudah. HUBBO POS memudahkan kemas kini menu merentas kedua-dua platform luar talian dan penghantaran makanan dengan satu klik.',
        },
      ],
    },
  ],
};
