import { Common } from '@/assets/svgs';
import solutionsFeatureImg1 from '@/assets/images/integrations-feature-2.png';
import solutionsFeatureImg2Small from '@/assets/images/integrations-feature-3-small.png';
import solutionsFeatureImg2Large from '@/assets/images/integrations-feature-3-large.png';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of integrations - section two
export const solutionFeaturesVariantTwo: SolutionsFeaturesProps = {
  title: 'Integrasi Terbuka melangkaui penghantaran makanan',
  backgroundColor: 'bg-background-secondary',
  rowReverseOnOdd: true,
  features: [
    {
      smallImage: solutionsFeatureImg1,
      largeImage: solutionsFeatureImg1,
      altText:
        'Mac laptop surrounded by various payment app icons representing Hubbo POS payment options.',
      content: [
        {
          icon: Common.Payment,
          title: 'Pelbagai Saluran Pembayaran',
          body: 'Sistem kami disepadukan dengan lancar dengan pelbagai saluran pembayaran, termasuk kad kredit, eDompet dan banyak lagi, menghapuskan keperluan untuk terminal tambahan dengan peranti HUBBO POS semua-dalam-satu.',
        },
        {
          icon: Common.StreamlinedAccounting,
          title: 'Perakaunan Diperkemas',
          body: 'Permudahkan pengurusan kewangan dengan perisian lancar HUBBO POS. Ia memastikan rekod kewangan anda dikemas kini, membolehkan anda menumpukan pada pertumbuhan perniagaan.',
        },
      ],
    },
    {
      smallImage: solutionsFeatureImg2Small,
      largeImage: solutionsFeatureImg2Large,
      altText:
        'Chef in white apron updates inventory on white tablet using Hubbo POS.',
      content: [
        {
          icon: Common.SupplyChain,
          title: 'Pengurusan rantaian bekalan',
          body: 'Optimumkan proses rantaian bekalan dengan sistem pengurusan inventori pintar kami. Kurangkan pembaziran, terima makluman stok yang rendah dan buat keputusan pembelian termaklum berdasarkan data masa nyata.',
        },
        {
          icon: Common.ProgressChartIcon,
          title: 'Perisikan Perniagaan',
          body: 'Dapatkan risikan perniagaan masa nyata dan akses penyegerakan pelaporan pusat beli-belah automatik untuk memperkasakan keputusan anda.',
        },
      ],
    },
  ],
};
