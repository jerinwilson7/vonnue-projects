import heroSmall from '@/assets/images/integrations-landing-small.jpg';
import heroLarge from '@/assets/images/integrations-landing-large.jpg';
import { Common } from '@/assets/svgs';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const heroBanner: SolutionsTemplateProps['heroBanner'] = {
  pageIndicatorIcon: Common.Integrations,
  pageIndicatorTitle: 'Integrasi',
  bannerTitle: 'Satukan operasi restoran anda di satu platform',
  bannerBody:
    'Penyepaduan berkuasa merentasi platform penghantaran, saluran pembayaran, kad kredit dan lain-lain.',
  heroSmallImage: heroSmall,
  heroLargeImage: heroLarge,
  imageAlt:
    'Restaurant owner in blue apron operates Hubbo POS, highlighting powerful delivery and payment integrations.',
};
