import { Common } from '@/assets/svgs';
import solutionsFeatureImg1 from '@/assets/images/feature-section-1.jpg';
import solutionsFeatureImg2 from '@/assets/images/feature-section-2.jpg';
import { SolutionsFeaturesProps } from '@/sections/solutions/SolutionFeatures';

// solution features of cloud POS
export const solutionFeatures: SolutionsFeaturesProps = {
  title: 'Maksimumkan Kecekapan dan Operasi Stor dengan Cloud',
  features: [
    {
      smallImage: solutionsFeatureImg1,
      largeImage: solutionsFeatureImg1,
      altText:
        'Restaurant owner serves customers using HUBBO POS for uninterrupted service, efficiency, and real-time reporting.',
      content: [
        {
          icon: Common.OfflineMode,
          title: 'Mod Luar Talian Yang Dipercayai',
          body: 'Alami perkhidmatan tanpa gangguan walaupun semasa gangguan Internet dengan penyegerakan dan sandaran data automatik.',
        },
        {
          icon: Common.Desk,
          title: 'Tingkatkan Perolehan Meja',
          body: 'Tingkatkan kecekapan restoran dengan proses automatik, pencegahan ralat dan perolehan meja yang lebih pantas.',
        },
        {
          icon: Common.InstantReporting,
          title: 'Pelaporan Masa Nyata',
          body: 'Dapatkan cerapan perniagaan terperinci pada bila-bila masa, di mana-mana sahaja dengan alat risikan perniagaan yang berkuasa HUBBO POS.',
        },
      ],
    },

    {
      smallImage: solutionsFeatureImg2,
      largeImage: solutionsFeatureImg2,
      altText:
        'Customer in orange shirt makes mobile payment using Hubbo POS with eWallets',
      content: [
        {
          icon: Common.SupportChat,
          title: 'Sembang Sokongan Langsung & Pusat Bantuan Komprehensif',
          body: 'Berhubung segera dengan pakar untuk sokongan perniagaan dan perkasakan perniagaan anda dengan sumber yang berharga melalui pusat bantuan mesra pengguna.',
        },
        {
          icon: Common.Payment,
          title: 'Penyepaduan Pembayaran Lancar',
          body: 'Tingkatkan pengalaman pembayaran pelanggan anda dengan pembayaran mudah yang disokong oleh E-Dompet dan kad kredit.',
        },
        {
          icon: Common.Display,
          title: 'Paparan Mesra Pelanggan',
          body: 'Tingkatkan pengalaman pembayaran keseluruhan dengan membenarkan pelanggan melihat butiran bil semasa pembayaran.',
        },
      ],
    },
  ],
};
