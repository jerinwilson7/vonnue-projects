import filterSmallImage from '@/assets/images/cta-small.png';
import filterLargeImage from '@/assets/images/cta-large.png';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const solutionsFilter: SolutionsTemplateProps['solutionsFilter'] = {
  largeImage: filterLargeImage,
  smallImage: filterSmallImage,
  altText:
    'Restaurant owner with white tablet uses HUBBO POS for reliable, efficient operational management.',
  buttonTitle: 'Dapatkan Demo Percuma',
  buttonLink: `/request-demo`,
  title: 'Pastikan Kesinambungan Perniagaan dengan HUBBO POS',
  body: 'HUBBO POS, sistem POS berasaskan cloud dengan mod luar talian, mengurangkan beban operasi dan memastikan kebolehpercayaan yang kukuh, walaupun pada hari sibuk.',
};
