import heroSmall from '@/assets/images/cloud-landing-small.jpg';
import heroLarge from '@/assets/images/cloud-landing-large.jpg';
import { Common } from '@/assets/svgs';
import { SolutionsTemplateProps } from '@/sections/solutions';

export const heroBanner: SolutionsTemplateProps['heroBanner'] = {
  pageIndicatorIcon: Common.CloudPos,
  pageIndicatorTitle: 'Cloud POS',
  bannerTitle: 'Kebolehpercayaan yang tiada tandingan dengan Cloud',
  bannerBody:
    'Manfaatkan kuasa pengkomputeran awan untuk kebolehpercayaan yang lebih besar dalam operasi kedai anda.',
  heroSmallImage: heroSmall,
  heroLargeImage: heroLarge,
  imageAlt:
    'Hubbo POS dashboard report displayed on tablet, highlighting cloud-based POS system capabilities.',
};
